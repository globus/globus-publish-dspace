/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

public class MessageEnvelope {
  public byte protocolMajorVersion = Common.COMPATIBILITY_MAJOR_VERSION;
  public byte protocolMinorVersion = Common.COMPATIBILITY_MINOR_VERSION;
  
  public int sessionId = 0;            // the ID of the multi-connection session
  public int requestId;                // the ID that identifies the request/response pair
  public int messageId = 0;            // the message ID (essentially the packet# where applicable);
  public int messageLength;

  public boolean truncated = false;
  public boolean encrypted = false;
  public boolean compressed = false;
  
  public String toString() {
    return "protocol="+protocolMajorVersion+'.'+protocolMinorVersion+"; session="+sessionId+
      "; req="+Integer.toHexString(requestId)+"h; msg="+messageId+"; len="+messageLength;
  }
}
