/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/***********************************************************************
 * Object used to represent an answer to a challenge to authenticate.
 ***********************************************************************/
public class ChallengeAnswerRequest
  extends AbstractRequest
{
  public byte authType[];
  public byte userIdHandle[];
  public int userIdIndex;
  public byte signedResponse[];

  public ChallengeAnswerRequest(byte authType[], byte userIdHandle[], 
                                int userIdIndex, byte signedResponse[],
                                AuthenticationInfo authInfo)
  {
    super(Common.BLANK_HANDLE, AbstractMessage.OC_RESPONSE_TO_CHALLENGE, authInfo);
    this.authType = authType;
    this.userIdHandle = userIdHandle;
    this.userIdIndex = userIdIndex;
    this.signedResponse = signedResponse;
  }

  public String toString() 
  {
    return super.toString()+' '+Util.decodeString(authType)+' '+
      userIdIndex+':'+Util.decodeString(userIdHandle);
  }
}
