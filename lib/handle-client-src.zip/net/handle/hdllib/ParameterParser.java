/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.util.*;

import net.cnri.util.StringUtils;

/**
   Class used to parse the URI representation of handles.  For example,
   the specific types of the handle can be specified on in the URI as
   (type=EMAIL)@0.NA/CNRI

   Parsing a handle URI with the ParameterParser will return a ParameterSet
   that contains the handle and any parameters from the URI.
 */
public abstract class ParameterParser {

  public static ParameterSet parseParameters(String handleString) {
    String parameterString="";
    String handle = handleString;
    int atIndex = handleString.indexOf('@');
    int slashIndex = handleString.indexOf('/');
    if(slashIndex<0) {
      return new ParameterSet(handleString, new ParameterPair[0],
			      new ParameterPair[0], new ParameterPair[0]);
    }
    if(atIndex>0 && atIndex<slashIndex) {
      parameterString = handle.substring(0,atIndex);
      handle = handle.substring(atIndex+1);
    } else if(atIndex<0) {
      return new ParameterSet(handleString, new ParameterPair[0],
			      new ParameterPair[0], new ParameterPair[0]);
    } else if(atIndex==0) {
      return new ParameterSet(handleString.substring(1), new ParameterPair[0],
			      new ParameterPair[0], new ParameterPair[0]);
    }

    int charIndex = 0;
    Vector handlePairs=new Vector();
    Vector defaultPairs=new Vector();
    Vector localPairs=new Vector();
    while(charIndex<parameterString.length()) {
      char ch = parameterString.charAt(charIndex);
      int groupEnd;
      switch (ch) {
      case '(':
	// start of the HANDLE parameter block...
	groupEnd = parameterString.indexOf(')',charIndex);
	if(groupEnd<0) { // no end paren found!!
	  groupEnd=parameterString.length();
	}
	parsePairs(parameterString.substring(charIndex+1,groupEnd),handlePairs);
	charIndex=groupEnd+1;
	break;
      case '{':
	// start of the LOCAL parameter block...
	groupEnd = parameterString.indexOf('}',charIndex);
	if(groupEnd<0) groupEnd=parameterString.length();
	parsePairs(parameterString.substring(charIndex+1,groupEnd),localPairs);
	charIndex=groupEnd+1;
	break;
      default:
	int groupEnd1 = parameterString.indexOf('{',charIndex);
	int groupEnd2 = parameterString.indexOf('(',charIndex);
	groupEnd = parameterString.length();
	if(groupEnd1>0)
	  groupEnd = groupEnd1;
	if(groupEnd2>0 && groupEnd2 < groupEnd)
	  groupEnd = groupEnd2;
	parsePairs(parameterString.substring(charIndex+1, groupEnd), defaultPairs);
	charIndex=groupEnd+1;
	break;
      }
    }
    
    // convert vectors into arrays...
    ParameterPair localPairArray[] = new ParameterPair[localPairs.size()];
    ParameterPair handlePairArray[] = new ParameterPair[handlePairs.size()];
    ParameterPair defaultPairArray[] = new ParameterPair[defaultPairs.size()];
    for(int i=0;i<localPairs.size();i++)
      localPairArray[i] = (ParameterPair)localPairs.elementAt(i);
    for(int i=0;i<handlePairs.size();i++)
      handlePairArray[i] = (ParameterPair)handlePairs.elementAt(i);
    for(int i=0;i<defaultPairs.size();i++)
      defaultPairArray[i] = (ParameterPair)defaultPairs.elementAt(i);
    return new ParameterSet(handle,defaultPairArray,handlePairArray,localPairArray);
  }

  private static final String SECTION_DELIMITER_URI_CHARS = "?!#&";
  private static final String HANDLE_DELIMITER_URI_CHARS = "?#";
  public static ParameterSet parseHandleURI(String handleURI) {
    int questionMarkEncountered = 0;  //how many question mark "?' is encounted
    boolean localParametersEntered = false;
    char chars[] = new char[handleURI.length()];
    handleURI.getChars(0, chars.length, chars, 0);

    // get the handle from the handle URI
    int hdlStart = 0;
    int currIdx = 0;

    while(currIdx < chars.length) {
      if(HANDLE_DELIMITER_URI_CHARS.indexOf(chars[currIdx])>=0) {
        break;
      }
      currIdx++;
    }

    int hdlEnd = currIdx;
    String handle = StringUtils.decodeURLIgnorePlus(chars, hdlStart, hdlEnd-hdlStart);

    Vector handlePairs = null;
    Vector localPairs= null;
    while(currIdx < chars.length) {
      char delim = chars[currIdx++];
      int paramStart = currIdx;
      
      // find the next set of parameters, or the end of the URI...
      while(currIdx < chars.length) {
        if(SECTION_DELIMITER_URI_CHARS.indexOf(chars[currIdx])>=0) {
          break;
        }
        currIdx++;
      }
      int paramEnd = currIdx;
      switch(delim) {
        case '?':
          questionMarkEncountered++;
          //the second "?" or "??" is meant for parameters for redirected URL
          if (questionMarkEncountered==1) {
            //the handle parameters
            if(handlePairs==null) handlePairs = new Vector();
            parsePairs(chars, paramStart, paramEnd, handlePairs);
          }
          break;

        case '&':
          if (questionMarkEncountered==1) {
            //the handle parameters
            if(handlePairs==null) handlePairs = new Vector();
            parsePairs(chars, paramStart, paramEnd, handlePairs);
          } 
          if (localParametersEntered) {
            //the content server parameters, or local parameters
            if(localPairs==null) localPairs = new Vector();
            parsePairs(chars, paramStart, paramEnd, localPairs);
          }
          break;

        case '!':
          localParametersEntered = true;
          if(localPairs==null) localPairs = new Vector();
          parsePairs(chars, paramStart, paramEnd, localPairs);
          break;
        default:
          System.err.println("unknown uri delimiter: "+delim);
      }
    }
    
    // convert vectors into arrays...
    ParameterPair handlePairArray[] = null;
    ParameterPair localPairArray[] = null;
    if(handlePairs!=null) {
      handlePairArray = new ParameterPair[handlePairs.size()];
      for(int i=0;i<handlePairs.size();i++)
        handlePairArray[i] = (ParameterPair)handlePairs.elementAt(i);
    }
    if(localPairs!=null) {
      localPairArray = new ParameterPair[localPairs.size()];
      for(int i=0;i<localPairs.size();i++)
        localPairArray[i] = (ParameterPair)localPairs.elementAt(i);
    }
    return new ParameterSet(handle, null, handlePairArray, localPairArray);
  }


  private static void parsePairs(String pairList, Vector pairVect) {
    int charIndex=0;
    while(charIndex<pairList.length()) {
      int semIndex = pairList.indexOf(';',charIndex);
      int ampIndex = pairList.indexOf('&',charIndex);
      if(ampIndex>=0 && ampIndex<semIndex) // allow ; or & as pair delimiters
        semIndex = ampIndex;
      if(semIndex<0)
        semIndex=pairList.length();
      String thisPair = pairList.substring(charIndex, semIndex);
      charIndex = semIndex+1;

      String name="";
      String value="";
      int eqIndex = thisPair.indexOf('=');
      if(eqIndex<0) {
        value = thisPair;
      } else {
        name = thisPair.substring(0, eqIndex);
        value = thisPair.substring(eqIndex + 1);
      }
      pairVect.addElement(new ParameterPair(name, value));
    }
  }

  private static void parsePairs(char uri[], int paramStart, int paramEnd, Vector pairVect) {
    int idx = paramStart;
    int pairStart = paramStart;
    int eqIdx = -1;
    while(idx < paramEnd) {
      if(eqIdx<0 && uri[idx]=='=')
        eqIdx = idx;
      if(uri[idx++]!=';')
        continue;

      // we hit a separator... add this parameter to the list
      ParameterPair pp;
      if(eqIdx>=0) {
        pp = new ParameterPair(new String(uri, paramStart, eqIdx-paramStart),
                               new String(uri, eqIdx+1, idx-eqIdx-1));
      } else {
        pp = new ParameterPair(new String(uri, paramStart, idx-paramStart-1),
                               "");
      }
      pairVect.addElement(pp);
      
      paramStart = idx;
      eqIdx = -1;
    }

    // add the last parameter to the list...
    if(paramStart!=idx) {
      ParameterPair pp;
      if(eqIdx>=0) {
        pp = new ParameterPair(new String(uri, paramStart, eqIdx-paramStart),
                              new String(uri, eqIdx+1, idx-eqIdx-1));
      } else {
        pp = new ParameterPair(new String(uri, paramStart, idx-paramStart-1),
                              "");
      }
      pairVect.addElement(pp);
    }
  }

}
