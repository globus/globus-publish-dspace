/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/***************************************************************************
 * Request used to retrieve all handles from a server.  This
 * request is used for server&lt;-&gt;server (or replicator&lt;-&gt;server)
 * communication.
 ***************************************************************************/

public class DumpHandlesRequest extends AbstractRequest {

  // to specify which handles to send (filtered by how the handles are hashed)
  public int serverNum;
  public byte rcvrHashType;
  public int numServers;

  public DumpHandlesRequest(byte rcvrHashType, int numServers, int serverNum, 
                            AuthenticationInfo authInfo) 
  {
    super( Common.BLANK_HANDLE, OC_DUMP_HANDLES, authInfo);
    this.rcvrHashType = rcvrHashType;
    this.numServers = numServers;
    this.serverNum = serverNum;
    this.certify = true;
    this.isAdminRequest = true;
    this.streaming = true;
  }
  
  
}
