/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/***********************************************************************
 * Interface for the transaction queue that is used as a callback from
 * messages like DumpHandlesRequest.
 ***********************************************************************/
public interface TransactionQueueInterface {

  public long getLastTxnId();

  public void addQueueListener(TransactionQueueListener l);

  public void removeQueueListener(TransactionQueueListener l);

  /** Log the specified transaction to the current queue or throw an exception
    * if there is an error or if this is a read-only queue.
    */
  public void addTransaction(long txnId, byte handle[], byte action, long date)
    throws Exception;
    
  public TransactionScannerInterface getScanner(long lastTxnId) throws Exception;

  public long getFirstDate();
  
  /** Close any open files or resources in use by the queue. */
  public void shutdown();

}

