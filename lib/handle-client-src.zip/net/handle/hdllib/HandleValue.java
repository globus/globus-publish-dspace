/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;
import java.util.*;

import net.cnri.util.FastDateFormat;

/** Represents a single handle value */
public class HandleValue {

  public static final byte SUBTYPE_SEPARATOR = (byte)'.';
  public static final byte TTL_TYPE_RELATIVE = 0;
  public static final byte TTL_TYPE_ABSOLUTE = 1;
  public static final int MAX_RECOGNIZED_TTL = 86400*2; // two days, higher ttl's will be ignored
  
  int index = -1;
  byte[] type = Common.EMPTY_BYTE_ARRAY;
  byte[] data = Common.EMPTY_BYTE_ARRAY;
  byte ttlType = TTL_TYPE_RELATIVE;
  int ttl = 86400;
  int timestamp = 0;
  ValueReference[] references = null;
  boolean adminRead = true;     // indicates whether or not admins can read this value
  boolean adminWrite = true;    // indicates whether or not admins can modify this value
  boolean publicRead = true;    // indicates whether or not anyone can read this value
  boolean publicWrite = false;   // indicates whether or not anyone can modify this value

  byte cachedBuf[] = null;
  int cachedBufOffset = 0;
  int cachedBufLength = 0;

  public HandleValue() {}

  public HandleValue(int index, byte type[], byte data[])
  {
    this.index = index;
    this.type = type;
    this.data = data;
  }

  public HandleValue(int index, byte type[], byte data[], byte ttlType, int ttl, 
                     int timestamp, ValueReference references[], boolean adminRead,
                     boolean adminWrite, boolean publicRead, boolean publicWrite) 
  {
    this.index = index;
    this.type = type;
    this.data = data;
    this.ttlType = ttlType;
    this.ttl = ttl;
    this.timestamp = timestamp;
    this.references = references;
    this.adminRead = adminRead;
    this.adminWrite = adminWrite;
    this.publicRead = publicRead;
    this.publicWrite = publicWrite;
  }

  public final String getPermissionString() {
    return new String(new char[] {
                                   adminRead?'r':'-',
                                   adminWrite?'w':'-',
                                   publicRead?'r':'-',
                                   publicWrite?'w':'-' });
  }
  
  public String toDetailedString() {
    return " index="+index+" type="+(type==null?"":new String(type))+" "+
      getPermissionString()+" ttl=" + ttlType + "/" + ttl + " timestamp=" + FastDateFormat.formatUtc(FastDateFormat.FormatSpec.ISO8601_NO_MS,1000L * timestamp) + " \""+
      (data==null?"":(Util.looksLikeBinary(data)?Util.decodeHexString(data,false):new String(data)))+
      '"';
  }

  public String toString() {
      return " index="+index+" type="+(type==null?"":new String(type))+" "+
        getPermissionString()+" \""+
        (data==null?"":(Util.looksLikeBinary(data)?Util.decodeHexString(data,false):new String(data)))+
        '"';
    }

  /** Given the current time and the time this value was retrieved from a
   *  handle server (in seconds), return true if this value is "stale" and
   *  should be retrieved again. */
  public boolean isExpired(int now, int timeRetrieved) {
    switch(ttlType) {
      case TTL_TYPE_RELATIVE:
        return ttl==0 || Math.min(ttl, MAX_RECOGNIZED_TTL) < (now-timeRetrieved);
      case TTL_TYPE_ABSOLUTE:
        return MAX_RECOGNIZED_TTL > (now-timeRetrieved) || ttl < now;
      default:
        //System.err.println("Unknown ttl type: "+ttlType);
        return true;
    }
  }

  /** Returns whether or not this handle value has the given type.
    * This handles subtypes, so if you call hasType("URL") and the
    * type of this handle value is "URL.METADATA" then this will
    * return true.
    */
  public final boolean hasType(byte someType[]) {
    return Util.equalsCI(this.type, someType) ||
      (someType.length < type.length &&
       type[someType.length]==SUBTYPE_SEPARATOR &&
       Util.startsWithCI(type, someType));
  }

  public final String getDataAsString() {
    if(data==null) return "";
    if(Util.looksLikeBinary(data))
      return Util.decodeHexString(data, false);
    return Util.decodeString(data);
  }
  
  public final String getTypeAsString() {
    return (type==null ? "" : Util.decodeString(type));
  }
 
  public final String getTimestampAsString() {
    // format "Thu Apr 13 11:08:57 EDT 2000"
    return (timestamp<=0 ? "NA" : (new Date(timestamp * 1000L)).toString());
  }

  public final String getNicerTimestampAsString() {
    // str has format Thu Apr 13 11:08:57 EDT 2000
    String str = (timestamp<=0 ? "NA" : (new Date(timestamp * 1000L)).toString());
    if (str!=null && str.length() >= 28) {
      // anotherStr has format "Thu Apr 13 2000 11:08:57 EDT"
      String anotherStr = str.substring(0,11) + str.substring(24,28) + " " +
                          str.substring(11, 19) + " " + str.substring(20, 23);
      return anotherStr;
    }
    return str;
  } 

  public final Date getTimestampAsDate() {
    return (timestamp<=0 ? null : (new Date(timestamp * 1000L)));
  }

  public final int getIndex() {
    return index;
  }
  
  public final void setIndex(int newIndex) {
    this.index = newIndex;
    cachedBuf = null;
  }
  
  public final byte[] getType() {
    return type;
  }
  
  public final void setType(byte newType[]) {
    this.type = newType;
    cachedBuf = null;
  }
  
  public final byte[] getData() {
    return data;
  }
  
  public final void setData(byte newData[]) {
    this.data = newData;
    cachedBuf = null;
  }
  
  public final byte getTTLType() {
    return ttlType;
  }
  
  public final void setTTLType(byte newTTLType) {
    this.ttlType = newTTLType;
    cachedBuf = null;
  }
  
  public final int getTTL() {
    return ttl;
  }
  
  public final void setTTL(int newTTL) {
    this.ttl = newTTL;
    cachedBuf = null;
  }
  
  public final int getTimestamp() {
    return timestamp;
  }
  public final void setTimestamp(int newTimestamp) {
    this.timestamp = newTimestamp;
  }

  public final ValueReference[] getReferences() {
    return references;
  }
  
  public final void setReferences(ValueReference newReferences[]) {
    this.references = newReferences;
    cachedBuf = null;
  }

  public final boolean getAdminCanRead() {
    return adminRead;
  }
  public final void setAdminCanRead(boolean newAdminRead) {
    this.adminRead = newAdminRead;
    cachedBuf = null;
  }

  public final boolean getAdminCanWrite() {
    return adminWrite;
  }
  public final void setAdminCanWrite(boolean newAdminWrite) {
    this.adminWrite = newAdminWrite;
    cachedBuf = null;
  }

  public final boolean getAnyoneCanRead() {
    return publicRead;
  }
  public final void setAnyoneCanRead(boolean newPublicRead) {
    this.publicRead = newPublicRead;
    cachedBuf = null;
  }

  public final boolean getAnyoneCanWrite() {
    return publicWrite;
  }
  public final void setAnyoneCanWrite(boolean newPublicWrite) {
    this.publicWrite = newPublicWrite;
    cachedBuf = null;
  }

  /**
   * Returns a copy of this HandleValue
   */
  public HandleValue duplicate() {
    ValueReference newRefs[] = null;
    ValueReference myRefs[] = references;
    if(myRefs!=null) {
      newRefs = new ValueReference[myRefs.length];
      for(int i=0; i<newRefs.length; i++)
        newRefs[i] = new ValueReference(myRefs[i].handle, myRefs[i].index);
    }
    return new HandleValue(index,
                           Util.duplicateByteArray(type),
                           Util.duplicateByteArray(data),
                           ttlType, ttl, timestamp, newRefs,
                           adminRead, adminWrite, publicRead, publicWrite);
  }
}
