/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;


public class Interface {
  // types of services
  public static final byte ST_OUT_OF_SERVICE = 0;
  public static final byte ST_ADMIN = 1;
  public static final byte ST_QUERY = 2;
  public static final byte ST_ADMIN_AND_QUERY = 3;

  public static final byte SP_HDL_UDP = 0;
  public static final byte SP_HDL_TCP = 1;
  public static final byte SP_HDL_HTTP = 2;
  
  public byte type;             // OUT_OF_SERVICE, ADMIN, QUERY, ADMIN_AND_QUERY
  public int port;              // usually 2641
  public byte protocol;         // UDP, TCP, HTTP

  public Interface(byte type, byte protocol, int port) {
    this.type = type;
    this.port = port;
    this.protocol = protocol;
  }
  
  public Interface cloneInterface() {
    Interface i2 = new Interface();
    i2.type = type;
    i2.port = port;
    i2.protocol = protocol;
    return i2;
  }
  
  public Interface() {
  }

  /** Return true if this interface will respond to request */
  public boolean canHandleRequest(AbstractRequest req) {
    if((req.streaming || req.requiresConnection) && protocol!=SP_HDL_TCP && protocol!=SP_HDL_HTTP) {
      return false;
    }
    if(req.isAdminRequest) {
      return (type==ST_ADMIN || type==ST_ADMIN_AND_QUERY);
    } else {
      return (type==ST_QUERY || type==ST_ADMIN_AND_QUERY);
    }
  }


  public String toString() {
    return typeName(type)+'/'+protocolName(protocol)+'/'+port;
  }


  public static final String typeName(byte type) 
  {
    switch(type) {
    case ST_OUT_OF_SERVICE:
      return "out-of-service";
    case ST_ADMIN_AND_QUERY:
      return "adm+qry";
    case ST_QUERY:
      return "qry";
    case ST_ADMIN:
      return "adm";
    default:
      return "UNKNOWN";
    }
  }

  public static final String protocolName(byte protocol)
  {
    switch(protocol) {
    case SP_HDL_HTTP:
      return "HTTP";
    case SP_HDL_TCP:
      return "TCP";
    case SP_HDL_UDP:
      return "UDP";
    default:
      return "UNKNOWN";
    }
  }
    
  @Override
  public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + port;
      result = prime * result + protocol;
      result = prime * result + type;
      return result;
  }

  @Override
  public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (getClass() != obj.getClass()) return false;
      Interface other = (Interface) obj;
      if (port != other.port) return false;
      if (protocol != other.protocol) return false;
      if (type != other.type) return false;
      return true;
  }
}
