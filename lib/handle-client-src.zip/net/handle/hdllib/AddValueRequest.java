/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/******************************************************************************
 * Request used to add a value to an existing handle.  Holds the handle
 * and the value to be added.
 ******************************************************************************/

public class AddValueRequest
  extends AbstractRequest
{

  public HandleValue values[];


  public AddValueRequest(byte handle[], HandleValue value,
                         AuthenticationInfo authInfo) {
    this(handle, new HandleValue[] { value }, authInfo);
  }

  public AddValueRequest(byte handle[], HandleValue values[], 
                         AuthenticationInfo authInfo) {
    super(handle, AbstractMessage.OC_ADD_VALUE, authInfo);
    this.values = values;
    this.isAdminRequest = true;
  }

}
