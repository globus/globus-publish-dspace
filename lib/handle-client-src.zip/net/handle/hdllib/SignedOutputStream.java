/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.security.*;
import java.io.*;

/**************************************************************************
 * Objects of this class can be used to sign the contents of a stream
 * that can be verified by a SignedInputStream class.
 *
 * Note: This is not a part of the official handle system specification.
 * This class and the format of the stream it creates will almost definitely
 * change with future versions of the handle system.  A possible improvement
 * is to use digest or MAC-based verification rather than full public/private
 * key signatures for each block.
 **************************************************************************/
public class SignedOutputStream
  extends OutputStream
{
  private OutputStream out;
  private Signature sig;

  /**************************************************************************
   * Create a stream that can verify the data read from the stream in
   * blocks.  The caller should call the verifyBlock method at the end
   * of every block of data that needs to be verified.  verifyBlock must 
   * be called at the same position in the stream that signBlock was called
   * in the parallel SignedOutputStream object that generated the stream.
   **************************************************************************/
  public SignedOutputStream(PrivateKey sourceKey, OutputStream out)
    throws Exception
  {
    super();
    this.out = out;

    // write the stream type identifier - currently there's only one: STREAM_TYPE_PK
    byte streamTypeBuf[] = new byte[Encoder.INT_SIZE];
    Encoder.writeInt(streamTypeBuf, 0, SignedInputStream.STREAM_TYPE_PK);
    out.write(streamTypeBuf);

    // write the header info specific to this stream type...

    // ...write the signature hash algorithm type
    byte hashID[] = Common.HASH_ALG_SHA1;
    byte hashIDLen[] = new byte[Encoder.INT_SIZE];
    Encoder.writeInt(hashIDLen, 0, hashID.length);
    out.write(hashIDLen);
    out.write(hashID);

    // initialize the signature
    sig = Signature.getInstance(Util.getSigIdFromHashAlgId(hashID, sourceKey.getAlgorithm()));
    sig.initSign(sourceKey);
  }

  /**************************************************************************
   * Write a byte to the stream.
   **************************************************************************/
  public void write(int b)
    throws IOException
  {
    try {
      sig.update((byte)b);
    } catch (SignatureException e) {
      throw new IOException("Error updating signature: "+e);
    }
    out.write(b);
  }

  /**************************************************************************
   * Signs the bytes written since the last signature on the stream.  This
   * should be called at the exact same point in the stream as the
   * verifyBlock method in the SignedInputStream class.
   **************************************************************************/
  public void signBlock()
    throws IOException,
           SignatureException
  {
    byte lenbuf[] = new byte[4];
    byte sigBytes[] = sig.sign();
    Encoder.writeInt(lenbuf, 0, sigBytes.length);
    out.write(lenbuf);
    out.write(sigBytes);
  }


  public void flush()
    throws IOException
  {
    out.flush();
  }
}

