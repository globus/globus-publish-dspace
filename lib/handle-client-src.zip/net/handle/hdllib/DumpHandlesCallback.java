/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import net.cnri.util.StreamTable;

/************************************************************************
 * Interface used to define objects that want to receive the streamed
 * results from DumpHandlesResponse messages.
 ************************************************************************/
public interface DumpHandlesCallback
{

  /********************************************************************
   * Process the given transaction which was received via the stream
   * in the DumpHandlesResponse message.
   ********************************************************************/
  public void addHandle(byte handle[], HandleValue values[])
    throws Exception;

  /********************************************************************
   * Process the given naming authority which was received via the
   * stream in the DumpHandlesResponse message.  If this message is
   * called, that means that the server is responsible for this naming
   * authority.
   ********************************************************************/
  public void addNamingAuthority(byte naHandle[])
    throws Exception;
  
  public void processThisServerReplicationInfo(long retrievalDate, long currentTxnId);
  
  public void processOtherSiteReplicationInfo(StreamTable replicationConfig) throws HandleException;
  
  public void setLastCreateOrDeleteDate(byte[] handle, long date, int priority) throws Exception;
  public void setLastHomeOrUnhomeDate(byte[] handle, long date, int priority) throws Exception;
}
