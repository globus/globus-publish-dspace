/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.io.*;
import java.util.*;
import net.cnri.simplexml.*;
import java.security.PublicKey;


/** Object containing information about a handle namespace.  A namespace is
  * basically a set of handles under a prefix and is usually identified by a 
  * prefix handle.  The prefix handle can be a local or global handle.  It usually
  * consists of everything before the first slash of a handle identifer, or it
  * can be a local prefix which includes the global prefix and also some part
  * of the identifer after the slash.  A handle could be contained within
  * multiple nested namespaces.
  */
public class NamespaceInfo {
  public static final String STATUS_ACTIVE = "active";
  public static final String STATUS_INACTIVE = "inactive";
  
  public static final String PUBKEY_TAG = "pubkey";
  public static final String CONTACT_TAG = "contact";
  public static final String STATUS_MSG_TAG = "statusmsg";
  public static final String STATUS_TAG = "status";
  public static final String DELEGATE_TAG = "del";
  public static final String LOCAL_DEL_ATT = "local";
  public static final String PREFIX_DEL_ATT = "prefix";
  public static final char LOCAL_DELEGATION_DELIMITER = '/';
  public static final String TEMPLATE_TAG = "template";
  public static final String LOCATIONS_TAG = "locs";
  public static final String TEMPLATE_DELIMITER_ATT = "delimiter";
  
  private static XParser xmlParser = new XParser();
  
  private final XTag xmlInfo;
  private NamespaceInfo parentNamespace = null;
  
  public NamespaceInfo(HandleValue namespaceValue) 
    throws HandleException
  {
    this(namespaceValue.getData());
  }
  
  public NamespaceInfo(byte rawInfo[]) 
    throws HandleException
  {
    try {
      xmlInfo = 
        xmlParser.parse(new InputStreamReader(new ByteArrayInputStream(rawInfo), "UTF8"), false);
    } catch (Exception e) {
      e.printStackTrace(System.err);
      if(e instanceof HandleException) throw (HandleException)e;
      throw new HandleException(HandleException.INVALID_VALUE,
                                "Error parsing namespace information: "+e);
    }
  }
  
  /** Construct a new namespace information record, with the default settings */
  public NamespaceInfo() {
    this.xmlInfo = new XTag("NAMESPACE");
  }
  
  /** Set the parent for this namespace.  This should be called when resolving 
    * an identifier that is contained within multiple nested namespaces.
    */
  public void setParentNamespace(NamespaceInfo parent) {
    this.parentNamespace = parent;
  }
  
  /** Get the parent for this namespace.  This can be useful for tracing back
    * namespaces when debugging or when verifying identifiers or sub-namespaces
    * based on signatures applied by parent namespaces.  If there is no higher
    * level namespace, then this will return null;
    */
  public NamespaceInfo getParentNamespace() {
    return this.parentNamespace;
  }
  
  
  /** Return an email address for the person or company that is responsible for
    * this namespace.
    */
  public String getResponsiblePartyContactAddress() {
    return xmlInfo.getStrSubTag(CONTACT_TAG, null);
  }
  
  /** Return a message that can be presented to a user who tries to resolve
    * an identifier under this namespace if the namespace status is not active.
    */
  public String getStatusMessage() {
    return xmlInfo.getStrSubTag(STATUS_MSG_TAG, null);
  }
  
  /** Return the status of this namespace as a String.  Currently known values
    * are "active" and "inactive" although it is possible that other values will
    * be used in the future.
    */
  public String getNamespaceStatus() {
    return xmlInfo.getStrSubTag(STATUS_TAG, STATUS_ACTIVE);
  }
  
  /** Return whether or not names under this namespace can be delegated to other
    * handle servers based on the local part of the handle (everything after the
    * first slash).
    */
  public boolean delegatesLocalNames() {
    XTag delTag = xmlInfo.getSubTag(DELEGATE_TAG);
    if(delTag!=null) return delTag.getBoolAttribute(LOCAL_DEL_ATT, false);
    if(parentNamespace!=null) return parentNamespace.delegatesLocalNames();
    return false;
  }
  
  /** Return whether or not names under this namespace can be delegated to other
    * handle servers based on the prefix part of the handle (everything before the
    * first slash).
    */
  public boolean delegatesPrefixes() {
    XTag delTag = xmlInfo.getSubTag(DELEGATE_TAG);
    if(delTag!=null) return delTag.getBoolAttribute(PREFIX_DEL_ATT, false);
    if(parentNamespace!=null) return parentNamespace.delegatesPrefixes();
    return false;
  }
  
  
  /** 
   * Return the handle containing the 10320/loc values that provide a set of 
   * locations for all handles under this namespace.
   */
  public String getLocationTemplateHandle() {
    XTag locTag = xmlInfo.getSubTag(LOCATIONS_TAG);
    if(locTag!=null) return locTag.getStrValue();
    if(parentNamespace!=null) return parentNamespace.getLocationTemplateHandle();
    return null;
  }
  
  /** Return whether or not names under this namespace can be templated */
  public String templateDelimiter() {
      XTag templateTag = xmlInfo.getSubTag(TEMPLATE_TAG);
      if(templateTag!=null) return templateTag.getAttribute(TEMPLATE_DELIMITER_ATT);
      if(parentNamespace!=null) return parentNamespace.templateDelimiter();
      return null;
  }

  public HandleValue[] templateConstruct(HandleValue[] origvals, String handle, String base, String extension, boolean caseSensitive, HandleResolver resolver, short recursionCount) {
      TemplateBuilder tb = new TemplateBuilder(origvals,handle,base,extension,caseSensitive,resolver,recursionCount);
      setupTemplateBuilderForNamespace(tb);
      return tb.templateConstruct();
  }
  
  void setupTemplateBuilderForNamespace(TemplateBuilder tb) {
      tb.setXml(xmlInfo);
      tb.setParentNamespace(parentNamespace);
  }

  public XTag getInheritedTag(String name) {
      XTag tag = xmlInfo.getSubTag(TEMPLATE_TAG);
      if(tag!=null) return tag;
      if(parentNamespace!=null) return parentNamespace.getInheritedTag(name);
      return null;
  }
  
  /** Return a list of public keys that can sign values within this namespace.
    * Keep in mind that these keys should not be considered valid unless the 
    * HandleValue that was used to construct this object was verified in some
    * way, such as with a signed handle response or using the SecureResolver.
    */
  public java.security.PublicKey[] getPublicKeys() {
    ArrayList keys = new ArrayList();
    for(int i=xmlInfo.getSubTagCount()-1; i>=0; i--) {
      XTag tag = xmlInfo.getSubTag(i);
      if(tag.getName().equalsIgnoreCase(PUBKEY_TAG)) {
        try {
          PublicKey key = Util.getPublicKeyFromBytes(Util.encodeHexString(tag.getStrValue()), 0);
          if(key!=null) keys.add(key);
        } catch (Exception e) {
          System.err.println("Error parsing public key from namespace info: "+
                             e+"\n"+tag);
        }
      }
    }
    return (java.security.PublicKey[])keys.toArray(new java.security.PublicKey[keys.size()]);
  }
  
  public String toString() {
    return (xmlInfo==null ? "<null>" : xmlInfo.toString()) + 
      "Parent: "+(parentNamespace==null ? "<null>" : String.valueOf(parentNamespace));
  }
  
}
