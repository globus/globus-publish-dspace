/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.io.InputStream;

public abstract class AbstractResponse 
  extends AbstractMessage
{

  // holder for input stream, so that client app can just
  // call processStreamedPart() to process the stream
  // if this is a "streaming" response.
  public InputStream stream = null;
  public boolean streaming = false;

  public AbstractResponse() {
    super();
  }

  public AbstractResponse(int opCode, int responseCode) {
    super(opCode);
    this.responseCode = responseCode;
  }

  public AbstractResponse(AbstractRequest req, int responseCode)
    throws HandleException
  {
    super(req.opCode);
    this.requestId = req.requestId;
    this.responseCode = responseCode;
    
    //session id passed to response here
    this.sessionId = req.sessionId;

    if(req.returnRequestDigest) {
      takeDigestOfRequest(req);
    }
    
    takeValuesFrom(req);

    setSupportedProtocolVersion();
  }

  /** If this message is to-be-continued, this method is called to get
      subsequent messages until it returns null which will indicate that
      the current message is the last. */
  public AbstractResponse getContinuedResponse() {
    return null;
  }

  final void takeDigestOfRequest(AbstractRequest req)
    throws HandleException
  {
    // create a digest of the original message
    ////// need to change to SHA1 when all clients are converted...
    if(!req.hasEqualOrGreaterVersion(2,1)) {
      requestDigest = Util.doMD5Digest(req.getEncodedMessageBody());
      rdHashType = Common.HASH_CODE_MD5_OLD_FORMAT;
    } else {
      requestDigest = Util.doSHA1Digest(req.getEncodedMessageBody());
      rdHashType = Common.HASH_CODE_SHA1;
    }
  }

  /*************************************************************
   * Write the response to the specified output stream.
   * By default this does nothing.  This should be over-ridden
   * by responses that set <I>streaming</i> to true.
   *************************************************************/
  public void streamResponse(java.io.OutputStream out) 
    throws HandleException
  { 
  }
}
