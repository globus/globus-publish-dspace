/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import java.math.*;
import java.security.interfaces.*;


public class RSAPrivateCrtKeyImpl 
  extends RSAPrivateKeyImpl
  implements RSAPrivateCrtKey
{
  //private BigInteger modulus;
  //private BigInteger privateExponent;
  private BigInteger publicExponent;
  private BigInteger primeP;
  private BigInteger primeQ;
  private BigInteger primeExponentP;
  private BigInteger primeExponentQ;
  private BigInteger crtCoefficient;
 
  
  public RSAPrivateCrtKeyImpl(BigInteger m, BigInteger pubExp, BigInteger exp,
                              BigInteger primeP, BigInteger primeQ,
                              BigInteger primeExpP, BigInteger primeExpQ, BigInteger crtCeoff) 
    throws NumberFormatException
  {
    //this.modulus = m;
    
    //this.privateExponent = exp;
    super(m, exp);
    this.publicExponent = pubExp;
    this.primeP = primeP;
    this.primeQ = primeQ;
    this.primeExponentP = primeExpP;
    this.primeExponentQ = primeExpQ;
    this.crtCoefficient = crtCeoff;
  }
  
  //public BigInteger getModulus()  { return modulus;}
  
  //public BigInteger getPrivateExponent() { return privateExponent;}
  
  public BigInteger getPublicExponent() { return publicExponent; }
  
  public BigInteger getCrtCoefficient() { return crtCoefficient; }
  
  public BigInteger getPrimeExponentP() { return primeExponentP; }
  
  public BigInteger getPrimeExponentQ() { return  primeExponentQ; }
  
  public BigInteger getPrimeP() { return primeP;}
  
  public BigInteger getPrimeQ() { return primeQ; }

  public String getAlgorithm() { return "RSA"; }

  public String getFormat() { return "HDL_RSA_PRIV"; }
  
  public byte[] getEncoded() {
    //// need to implement
    return null;
  }
}
