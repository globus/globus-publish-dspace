package net.handle.util;

import java.math.BigInteger;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.util.Date;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.x500.AttributeTypeAndValue;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import net.cnri.util.FastDateFormat;
import net.handle.hdllib.Util;
import net.handle.hdllib.ValueReference;

public class X509HSCertificateGenerator {
    private static SecureRandom random = new SecureRandom();
    static {
        random.setSeed(System.nanoTime());
    }
    
    public static X509Certificate generate(String handle, PublicKey pubKey, PrivateKey privKey) throws Exception {
        int colon = handle.indexOf(':');
        if(colon < 0) return generateWithUid(handle,pubKey,privKey);
        String maybeIndex = handle.substring(0,colon);
        if(isDigits(maybeIndex)) return generateWithUid("0:" + handle,pubKey,privKey);
        return generateWithUid(handle,pubKey,privKey);
    }

    public static X509Certificate generate(String handle,int index,PublicKey pubKey,PrivateKey privKey) throws Exception {
        return generateWithUid("" + index + ":" + handle,pubKey,privKey);
    }
        
    public static X509Certificate generate(ValueReference valRef,PublicKey pubKey,PrivateKey privKey) throws Exception {
        return generateWithUid("" + valRef.index + ":" + Util.decodeString(valRef.handle),pubKey,privKey);
    }

    private static final Date notBefore, notAfter;
    static {
        try {
            notBefore = new Date(FastDateFormat.parseUtc("20000101000000Z"));
            notAfter = new Date(FastDateFormat.parseUtc("99991231235959Z"));
        } catch(ParseException e) {
            throw new AssertionError(e);
        }
    }
    
    public static X509Certificate generateWithUid(String uid, PublicKey pubKey, PrivateKey privKey) throws Exception {
        X500Name name;
        if(uid==null) {
//            String anon = Util.decodeHexString(Util.doSHA1Digest(pubKey.getEncoded()), false);
            name = new X500Name(new RDN[] { 
                    new RDN(new AttributeTypeAndValue(BCStyle.CN,new DERUTF8String("anonymous"))), 
            });
        } else {
            name = new X500Name(new RDN[] { 
                    new RDN(new AttributeTypeAndValue(BCStyle.UID,new DERUTF8String(uid))), 
            });
        }
        SubjectPublicKeyInfo pubKeyInfo = SubjectPublicKeyInfo.getInstance(new ASN1InputStream(pubKey.getEncoded()).readObject());
        X509v3CertificateBuilder builder = new X509v3CertificateBuilder(name,BigInteger.valueOf(Math.abs(random.nextLong())),notBefore,notAfter,name,pubKeyInfo);
        ContentSigner signer = new JcaContentSignerBuilder("SHA1with" + privKey.getAlgorithm()).build(privKey);
        X509CertificateHolder certHolder = builder.build(signer);
        return new JcaX509CertificateConverter().getCertificate(certHolder);
    }
    
    public static void storeCertAndKey(KeyStore keyStore, Certificate cert, PrivateKey privKey, String alias, String keyPass) throws KeyStoreException {
        keyStore.setKeyEntry(alias,privKey,keyPass.toCharArray(),new Certificate[] { cert });
    }
    
    private static boolean isDigits(String s) {
        for(int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if(ch<'0' || ch>'9') return false;
        }
        return true;
    }
}
