/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import net.handle.apps.admin_servlets.TemplateException;

/**
 * @deprecated Replaced by net.cnri.util.Template
 */
@Deprecated
public class Template extends net.cnri.util.Template {
    public static String subDictIntoFile(String filename,Map dict) throws IOException, TemplateException {
        try {
            return net.cnri.util.Template.subDictIntoFile(filename,dict);
        }
        catch(net.cnri.util.TemplateException e) {
            throw new TemplateException(e.getMessage());
        }
    }

    public static String subDictIntoFile(File file,Map dict) throws IOException, TemplateException {
        try {
            return net.cnri.util.Template.subDictIntoFile(file,dict);
        }
        catch(net.cnri.util.TemplateException e) {
            throw new TemplateException(e.getMessage());
        }
    }
    
    public static String subDictIntoStream(InputStream in, Map dict) throws IOException, TemplateException {
        try {
            return net.cnri.util.Template.subDictIntoStream(in,dict);
        }
        catch(net.cnri.util.TemplateException e) {
            throw new TemplateException(e.getMessage());
        }
    }

    public static String subDictIntoString(String str, Map dict) throws TemplateException {
        try {
            return net.cnri.util.Template.subDictIntoString(str,dict);
        }
        catch(net.cnri.util.TemplateException e) {
            throw new TemplateException(e.getMessage());
        }
    }
}