/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

/**
 * @deprecated Replaced by net.cnri.util.TemplateException
 */
@Deprecated
public class TemplateException extends net.cnri.util.TemplateException {
    public TemplateException(String str) {
        super(str);
    }
    public TemplateException() {
        super();
    }
}
