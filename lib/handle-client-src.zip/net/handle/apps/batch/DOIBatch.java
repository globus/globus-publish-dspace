/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.batch;

import net.handle.hdllib.*;
import net.handle.util.IntTable;

import java.io.*;
import java.util.*;


public abstract class DOIBatch {
  private AuthenticationInfo authInfo = null;
  public static final String DOI_ADMIN_NA = "10.admin";
  
  public static final int SEC_KEY_IDX = 300;
  private static HandleResolver resolver = new HandleResolver();

  private static Writer log = null;
  
  //a file for statistics purpose
  private static Writer logStat = null;

  //If some of the DOI operations failed, DOI will be written into
  //"failedbatchfile", then we will try to process this generated
  //file one time. This is mainly to address CANNOT_CONNECT_TO_SERVER
  //exceptions. Other failures don't actually deserve to be re-executed
  //again.
  private static Writer failedBatchDOIsWriter = null; 
  private static File failedBatchDOIs = null; 
  private static String FAILED_BATCH_FILE_NAME = "failedbatchfile$$";
  
  static {
    resolver.setTcpTimeout(20000); 
   // resolver.traceMessages = true;
  }
  
  public static void printUsage() {
    System.err.println("Usage: java net.handle.apps.batch.DOIBatch "+
                       "{ACDNU}[sS] <batchfile> <username> <password> "+
                       "<logfile> <statistics_file>\nOptions:\n"+
                       "\t-A assign aliases for handles\n"+
                       "\t-C create handles\n"+
                       "\t-D delete handles\n"+
                       "\t-N remove aliases for handles\n"+
                       "\t-U update handles\n"+
                       "\t-s specify statistics file name\n"+
                       "\t-S use sessions\n"+
                       "Arguments within braces ({}) indicate that one of "+
                       "the arguments must be specified.\nArguments "+
                       "within brackets ([]) indicate optional arguments.\n");
  }

  public static void main(String argv[])
    throws Exception
  {
    if(argv.length < 5) {
      printUsage();
      System.exit(-1);
      return;
    }
      
    String opt = argv[0];
    String username = argv[2];
    String passwd = argv[3];
    boolean useSession = false;

    log = new OutputStreamWriter(new FileOutputStream(argv[4]),"UTF-8");
    
    if (opt.indexOf('S')>=0) {
          useSession = true;
    }
    
    //statistics flag saves each request execution time to stat file
    if (opt.indexOf('s')>=0) {
      if (argv.length > 5) {
        logStat = new OutputStreamWriter(new FileOutputStream(argv[5]),"UTF-8");
      } else {
        System.err.println("Statistics file name must be specified "+
                                "with 's' option.");
        System.exit(-1);
      }
    }
      
    //create the trace message file
    if (resolver.traceMessages) {  
      try {
        System.setErr(new PrintStream(new FileOutputStream(argv[4]+"Trace", true), true));
      }
      catch (Exception e) {
        System.err.println("Can not reassign the standard error to file.");
      } 
    }
    
    byte idHandle[] = Util.encodeString(DOI_ADMIN_NA+'/'+username);
  
    SecretKeyAuthenticationInfo auth =
      new SecretKeyAuthenticationInfo(idHandle, SEC_KEY_IDX, Util.encodeString(passwd));

    //use public key
    //byte[] keybyte = Util.getBytesFromFile("c:\\hs\\svr_1\\***");
    //byte[] privkeybyte = Util.decrypt(keybyte, Util.encodeString("****"));
    //PrivateKey pkey = Util.getPrivateKeyFromBytes(privkeybyte, 0);
    //PublicKeyAuthenticationInfo auth = new PublicKeyAuthenticationInfo(Util.encodeString("****"), 300, pkey);

    //delete existing batch file
    failedBatchDOIs = new File(FAILED_BATCH_FILE_NAME);
    if (failedBatchDOIs.exists()) failedBatchDOIs.delete();
    failedBatchDOIs = null;

    int trying = 0;
    boolean prepSessionSuccess = true;

    //allow to process failedDOIBatch file in which all failed DOI
    //lines in first round try are recorded
    while (trying == 0 || 
           (trying == 1 && failedBatchDOIs != null && failedBatchDOIs.exists())) { 

    String currProcessDOI = argv[1];

    if (trying > 0) {
      //open log file again to append logging
      currProcessDOI = FAILED_BATCH_FILE_NAME;
      log = new OutputStreamWriter(new FileOutputStream(argv[4], true), "UTF-8");
      log.write("\n\n"); 
      log.write("====================================================================\n");
      log.write("             Retrying to process failed DOIs ....\n");
      log.write("====================================================================\n\n");
    }

    if(useSession) {
      // SessionSetupInfo ssinfo = null;

      // DH key exchange
      // ssinfo = new SessionSetupInfo(auth);

      // HDL cipher key exchange
      /*
      try {
        File f = new File("rsapriv.bin");
        byte buf[] = new byte[(int)f.length()];
        FileInputStream in = new FileInputStream(f);
        in.read(buf);
        buf = Util.decrypt(buf, null);
        PrivateKey privkey = Util.getPrivateKeyFromBytes(buf, 0);
        
        ssinfo = new SessionSetupInfo(auth, "10.test/rsa",1,privkey);
      }
      catch (Exception e){
        System.out.println("Error setting up session"); 
        e.printStackTrace();
        System.exit(-1);
      }
    */

      // Server cipher key exchange
      // ssinfo = new SessionSetupInfo(Common.KEY_EXCHANGE_CIPHER_SERVER, auth);
      // resolver.setSessionTracker(new ClientSessionTracker(ssinfo));
    }
    
    try {
      FileInputStream f = new FileInputStream(currProcessDOI);
      BufferedReader in = new BufferedReader(new InputStreamReader(f, "UTF-8"));
      if(opt.indexOf('C')>=0) {
        processBatchCreate(auth, in, new PrintWriter(System.out));
      } else if(opt.indexOf('D')>=0) {
        processBatchDelete(auth, in, new PrintWriter(System.out));
      } else if(opt.indexOf('A')>=0) {
        processBatchAlias(auth, in, new PrintWriter(System.out));
      } else if(opt.indexOf('N')>=0) {
        processBatchUnalias(auth, in, new PrintWriter(System.out));
      } else if(opt.indexOf('U')>=0) {
        processBatchUpdate(auth, in, new PrintWriter(System.out));
      } else if(opt.indexOf('M')>=0) {
        processBatchModify(auth, in, new PrintWriter(System.out));
      } else {
        printUsage();
        System.exit(-1);
      }
    } catch (Exception e) {
      log.write("Error processing batch: "+e+"\n");
      e.printStackTrace();
      log.close();
      if (logStat != null) logStat.close();
      System.exit(-1);
    } finally {
        
      
      try { log.close(); 
        if (logStat != null) logStat.close();
      } catch (Exception e) {}

      //close the batch failure file
      try { if (failedBatchDOIsWriter != null) failedBatchDOIsWriter.close();
      } catch (Exception e){}
    }

    trying++;
    }

    //delete the failed batch fiel at the end
    if (failedBatchDOIs != null && failedBatchDOIs.exists()) {
      failedBatchDOIs.delete();
    } 

    //try to release session
    /*
    if(useSession) {
      try {
        resolver.releaseSessions(sessionTracker);
      } catch (Exception e) {
        System.err.println("Error closing session: "+e);
      }
    }
    */

    //add the trace file to the end of the log file
    FileOutputStream logOut = null;
    File tracefile = null;
    File outfile = null;
    FileInputStream traceIn = null;
    try {
      if (resolver.traceMessages) {
        logOut = new FileOutputStream(argv[4], true);
        logOut.write(Util.encodeString("\n     ---------------------------------"));
        logOut.write(Util.encodeString("\nHere comes the tracing messages ...\n"));
        tracefile = new File(argv[4]+"Trace");
        traceIn = new FileInputStream(tracefile);

        byte[] block = new byte[4096];
        int r= 0;
        while (true ) {
          r=traceIn.read(block);
          logOut.write(block, 0, r);        
          logOut.flush();
          
          if (r < 4096) { 
            break; }
        }        
      }
    }
    catch (Exception e){
        e.printStackTrace();
    } finally {
        if (logOut!=null) logOut.close();
        if (traceIn != null) traceIn.close();
       
        System.err.close();
        if (tracefile != null && tracefile.exists()) {
          tracefile.delete();
        }
    }
    
    System.out.println("FINISHED.");
  }
  
  static void writeToBatchFailure(String failedLine) {
    if (failedBatchDOIs == null || failedBatchDOIsWriter == null) {
     
      try {
        failedBatchDOIs = new File(FAILED_BATCH_FILE_NAME);
        failedBatchDOIsWriter = new OutputStreamWriter(new FileOutputStream(failedBatchDOIs),"UTF-8");
      }
      catch (Exception e) {
        failedBatchDOIs = null;
        failedBatchDOIsWriter = null;
      }
    }

    try {
      if (failedBatchDOIsWriter != null)
        failedBatchDOIsWriter.write(failedLine + "\n");
    }
    catch (IOException ioe) {
    }
  }

  static void processBatchCreate(AuthenticationInfo auth,
                                 BufferedReader in,
                                 PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int startIdx = 0;
    int endIdx = 0;
    int lineNum = 0;
    int successes = 0;
    int warnings = 0;
    int records = 0;
    
    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    
    //write proper header into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: CREATE \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status\n\n");
    }
    
    long eachStart = 0;
    while(true){
      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx<=0){
        log.write("Invalid line ("+lineNum+"): "+line+"\n");
        continue;
      }
   
      if (logStat!= null) eachStart = System.currentTimeMillis();
   
      String handle = line.substring(0, spaceIdx);
      Vector url = new Vector(); 
      
      if(line.length() > 0){
      	startIdx = line.indexOf(' ', 0);
      	endIdx = line.indexOf(' ', startIdx+1);
      	for(int i=0; i<line.length(); i++){
      		if(endIdx == -1){
      		  endIdx = line.length();
						url.addElement(line.substring(startIdx+1,endIdx).trim());
						break;
					}
					if((line.substring(startIdx+1,endIdx).trim()).length() > 0)
						url.addElement(line.substring(startIdx+1,endIdx).trim());
      		if(endIdx != 0){
      			startIdx = endIdx;
      			endIdx = line.indexOf(' ', startIdx+1);
      		}
      	}
      }
      
      HandleValue values[] = new HandleValue[url.size()+1];
			for(int j=0; j<url.size(); j++){
				values[j] = new HandleValue();
				values[j].setIndex(j+1);
				values[j].setType(Common.STD_TYPE_URL);
        values[j].setData(Util.encodeString((String) url.elementAt(j)));
			}
			values[url.size()] = new HandleValue();
			values[url.size()].setIndex(100);
			values[url.size()].setType(Common.STD_TYPE_HSADMIN);
			values[url.size()].setData(null);
           
    	log.write("Operation: create\n");
      CreateHandleRequest chReq = new CreateHandleRequest(null, values, auth);
      chReq.handle = Util.encodeString(handle);
      
      AdminRecord admin =
        new AdminRecord(Util.getZeroNAHandle(Util.getPrefixPart(chReq.handle)),
                        200, false, true, false, false, true,
                        true, true, true, true, true, true, true);
      chReq.values[url.size()].setData(Encoder.encodeAdminRecord(admin));
     
      records++;
      chReq.clearBuffers();
      AbstractResponse response = null;
      try {
        response = resolver.processRequest(chReq);

        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          successes++;
          log.write("SUCCESS:"+(lineNum-1)+":ADD:"+handle+"\n");
        } else if (response.responseCode == AbstractMessage.RC_HANDLE_ALREADY_EXISTS){
          log.write("WARNING: HANDLE ALREADY EXISTS: line "+(lineNum-1)+" "+line+"\n");
          warnings++;
          
        } else {
          log.write("ERROR: "+response+ ": line "+(lineNum-1)+" "+line+"\n"); 
        }
      } catch (HandleException e) {
        log.write("ERROR: "+e.getMessage()+": line "+(lineNum-1)+" "+line+"\n");
        
        if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
          //write to retry file if CANNOT_CONNECT_TO_SERVER caught
          writeToBatchFailure(line);
      }
      try { log.flush(); } catch (Throwable t) {}
      
      if (logStat!= null) {
        double fl = (System.currentTimeMillis() - eachStart)/1000.0f;
        logStat.write( (fl) + "\n");
        try { logStat.flush(); } catch (Throwable t) {}
      }
      
    }

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000f;    //in seconds
    log.write("Batch total execution time "  + Float.toString(totalExec) + " seconds.\n");
    
    log.write("SUMMARY:CREATE: "+
              successes+'/'+records+" successes "+
              (records-successes-warnings)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = records>0 ? totalExec/records : Float.NaN;
    log.write("STATISTICS SUMMARY:CREATE PROCESSING TIME: " + Float.toString(perRequestExec) + " seconds per request.\n\n");
    
    //stat info for average processing time
    if (logStat != null){
      logStat.write( "\nTotal processing time: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
    }    
  }

  static void processBatchUpdate(AuthenticationInfo auth,
                                 BufferedReader in,
                                 PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int startIdx = 0;
    int endIdx = 0;
    int lineNum = 0;
    int successes = 0;
    int records = 0;
    
    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    
    //write proper header into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: UPDATE \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status \n\n");
      
      logStat.write("RESOLUTION REMOVE_VAL ADD_VAL\n");
    }
    
    long eachStart = 0;
    long eachReslDone = 0;
    long eachRemValDone = 0;
    
    while(true) {
      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx<=0) {
        log.write("Invalid line ("+lineNum+"): "+line+"\n");
        continue;
      }
  
    //stat purpose
    if (logStat != null)
      eachStart = System.currentTimeMillis();
      
    //read in new URLs for each handle in batch file
    Vector newUrls = new Vector(); 
    if(line.length() > 0){
    	startIdx = line.indexOf(' ', 0);
     	endIdx = line.indexOf(' ', startIdx+1);
     	for(int i=0; i<line.length(); i++){
     		if(endIdx == -1){
     		  endIdx = line.length();
					newUrls.addElement(line.substring(startIdx+1,endIdx).trim());
					break;
				}
				if((line.substring(startIdx+1,endIdx).trim()).length() > 0)
					newUrls.addElement(line.substring(startIdx+1,endIdx).trim());
  	 		if(endIdx != 0){
     			startIdx = endIdx;
     			endIdx = line.indexOf(' ', startIdx+1);
     		}
     	}
    }
   
    String handle = line.substring(0, spaceIdx);
  
   //get old URLs for each handle in batch file 	
    ResolutionRequest rReq =
        new ResolutionRequest(Util.encodeString(handle), null, null, auth);
        
    rReq.authoritative = true;
    AbstractResponse response;
    HandleValue currentValues[];
    try {
      response = resolver.processRequest(rReq);
  	  if(response.responseCode==AbstractMessage.RC_SUCCESS) {
  	    currentValues = ((ResolutionResponse)response).getHandleValues();
           // System.out.println("getting success");
    	} else if(response.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
  		    currentValues = null;
          log.write("WARNING: HANDLE NOT FOUND: line "+(lineNum-1)+" "+line+"\n");
          continue;

      } else {
          log.write("ERROR: "+response.responseCode+" "+
                    AbstractMessage.getResponseCodeMessage(response.responseCode)+
                    ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
                    
          continue;
        }
  	} catch (HandleException e) {
        log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                  ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
                  
        //if the exception is CANNOT_CONNECT_TO_SERVER, write to file, and retry later
        if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
        continue;
      }
  	
  	//stat info, write the resolution time into each line, append with tab
  	if (logStat != null) {
  	  eachReslDone = System.currentTimeMillis();
  	  logStat.write( (eachReslDone - eachStart)/1000f + "\t");
  	}
  	
    Vector deleteValues = new Vector();
    int indices[] = null;
    if (currentValues != null) {
    indices = new int[currentValues.length];
    }
    for(int i=0; currentValues!=null && i<currentValues.length; i++) {
      indices[i] = currentValues[i].getIndex();
      if(currentValues[i].hasType(Common.STD_TYPE_URL))
       	deleteValues.addElement(currentValues[i]);
    }
 
    //delete old URLs for each handle in batch file
    RemoveValueRequest rmReq = new RemoveValueRequest(null, null, auth);
    if(deleteValues!=null) {
    	rmReq.handle = Util.encodeString(handle);
      int indexesToDelete[] = new int[deleteValues.size()];
      for(int i=0; i<indexesToDelete.length; i++) {
        indexesToDelete[i] = ((HandleValue)deleteValues.elementAt(i)).getIndex();
      }
    	rmReq.indexes = indexesToDelete;
    	rmReq.clearBuffers();
    	try {
    		response = resolver.processRequest(rmReq);
  	    	if(response.responseCode==AbstractMessage.RC_SUCCESS ||
      	  	 response.responseCode==AbstractMessage.RC_VALUES_NOT_FOUND) {
      		}else{
    				log.write("ERROR: "+response.responseCode+" "+
                     AbstractMessage.getResponseCodeMessage(response.responseCode)+
                     ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");
        		continue;
        	}
    	} 
    	catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                    ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");

          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            //write to retry file if CANNOT_CONNECT_TO_SERVER caught
            writeToBatchFailure(line);
          continue;
    	}
    }

    //write remove value processing time into stat file
    if (logStat != null) {
  	  eachRemValDone = System.currentTimeMillis();
  	  logStat.write( (eachRemValDone - eachReslDone)/1000f + "\t");
  	}
  	
    //add new URLs for each handle in batch file
  	HandleValue newValues[] = new HandleValue[newUrls.size()];
  	int newIdx = 1; //indicates the index to try for the new url
  	int test = 0; 
  	int found = 1; //indicates if index is already in use
    
  	for(int j=0; j<newUrls.size(); j++){ 
  		while(test != -1){
                        int currentLength = 0;
                        if (currentValues!= null) 
                                 currentLength = currentValues.length;  
  			for(int i=0; i<currentLength; i++){//search for a free index
  				if(indices[i] == newIdx){ //if newIdx is found in the list of used indices, 
  																	//test to see if the index has been deleted.
  																	//If it has, use this index for the new url.
  					for(int k=0; k<deleteValues.size(); k++){
  						if(newIdx == ((HandleValue)deleteValues.elementAt(k)).getIndex()){
  							found = 0;
  							test = 2;
  							break;
  						}
  					}
  					if(test == 2) 
  						break;
  					newIdx++; //the used index was not deleted, so try a new index
  					found = 1;
  					break;
  				}
  				else found = 0;	//the newIdx was not found in the list of used indices, so newIdx
  												//is the index to use for the new url.
  			}
  			if(found == 0)test = -1;  //break out of while loop because a useable index has been found
  		}
  		newValues[j] = new HandleValue();
			newValues[j].setIndex(newIdx);
			newValues[j].setType(Common.STD_TYPE_URL);	
			newValues[j].setData(Util.encodeString((String) newUrls.elementAt(j)));
			newIdx++;
			test = 0;
			found = 1;
		}
	
		log.write("Operation: update\n");
		AddValueRequest avReq = new AddValueRequest(null, newValues, auth);	
		avReq.handle = Util.encodeString(handle);
    
    records++;
      try {
        response = resolver.processRequest(avReq);


        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          successes++;
          log.write("SUCCESS:"+(lineNum-1)+":UPDATE:"+handle+"\n");
        } else {
          log.write("ERROR: "+response.responseCode+" "+
                    AbstractMessage.getResponseCodeMessage(response.responseCode)+
                    ": line "+(lineNum-1)+" "+line+"\n");
          
        }
      } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");
   
          //if exception caught, maybe a "CANNOT_CONNECT_TO_SERVER", then write into a batch failure file, let try later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
      }
      try { log.flush(); } catch (Throwable t) {}
     
      //write stat info
      if (logStat != null){
        logStat.write( (System.currentTimeMillis() - eachRemValDone)/ 1000.0f + "\n");
        try { logStat.flush(); } catch (Throwable t) {}
      }
  	}

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000f;     //in seconds
    log.write("Batch total execution time "  + totalExec + " seconds.\n");
    
    log.write("SUMMARY:UPDATE: "+
              successes+'/'+records+" successes "+
              (records-successes)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = records>0 ? totalExec/records : Float.NaN;
    log.write("SUMMARY:UPDATE PROCESSING TIME: " + (perRequestExec) + " seconds per request.\n\n");
    
    if (logStat != null){
      logStat.write( "\nTotal processing time: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
    }
  }
  
  static void processBatchModify(AuthenticationInfo auth,
                                 BufferedReader in,
                                 PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int startIdx = 0;
    int endIdx = 0;
    int lineNum = 0;
    int successes = 0;
    int records = 0;

    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    
    //write proper header into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: MODIFY \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status \n\n");
    }

    long eachStart = 0;
    
    while(true) {
      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx<=0) {
        log.write("Invalid line ("+lineNum+"): "+line+"\n");
        continue;
      }
      
      //stat purpose
      if (logStat != null)
        eachStart = System.currentTimeMillis();
  
      //read in new URLs for each handle in batch file
      //the line has the format 
	  //10.5555/handleX index1 URL_value1 index2 URL_value2
      Vector newUrls = new Vector(); 
	  java.util.StringTokenizer st = new StringTokenizer(line, " ");
	  String handle="";
	  int indEle = 0;
	
	  while (st.hasMoreTokens()){
	    if (indEle==0) handle=st.nextToken();
	    if (indEle > 1) {
		  //read by pair of (index url)
		  String idxStr = st.nextToken();
		  int index = -1;
		  try {
		    index = Integer.parseInt(idxStr);
		  }
		  catch (Exception e){
		    log.write("ERROR: "+"Index <" + idxStr + "> is not an integer, line "+(lineNum-1)+" "+line+"\n");
            continue;
		  }
		  if (index < 0) {
		    log.write("ERROR: "+"Index <" + idxStr + "> is not a positive number, line "+(lineNum-1)+" "+line+"\n");
            continue;
		  }	
		
  	      String url="";
		  if (st.hasMoreElements()){
		    url = st.nextToken(); 
		  } else {
		    log.write("ERROR: "+"Missing url string, line "+(lineNum-1)+" "+line+"\n");
            continue;
	   	  }
		  HandleValue hv = new HandleValue();
		  hv.setIndex(index);
		  //System.out.println("setting index " + index);
	      hv.setType(Common.STD_TYPE_URL);
		  hv.setData(Util.encodeString(url));
		  //System.out.println("setting data " + url);
		  newUrls.addElement(hv);
	    }
	    indEle++;
 	  }
  
	  if (newUrls.size() > 0 && handle.length() > 0)   {
        //get old URLs for each handle in batch file 	
        ResolutionRequest rReq =
          new ResolutionRequest(Util.encodeString(handle), null, null, auth);
        AbstractResponse response;
        HandleValue currentValues[] = null;
        try {
    	  response = resolver.processRequest(rReq);
  	      if(response.responseCode==AbstractMessage.RC_SUCCESS) {
  	        currentValues = ((ResolutionResponse)response).getHandleValues();
    	  } else if(response.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
  		    currentValues = null;

            log.write("WARNING: HANDLE NOT FOUND: line "+(lineNum-1)+" "+line+"\n");
            continue; 
          
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
            continue;
          }
  	    } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                    ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
                    
          //if the exception is CANNOT_CONNECT_TO_SERVER, write to file, and retry later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
          continue;
        }
 	
	    IntTable curUrlIndex  = new IntTable();
        for(int i=0; currentValues!=null && i<currentValues.length; i++) {
          if(currentValues[i].hasType(Common.STD_TYPE_URL))
         	  curUrlIndex.put(currentValues[i].getIndex(), currentValues[i]);
        }
	
        //modify new URLs for each handle in batch file
        //check if the indexes specified are current url indexes
        //we may add new value if there are no existing index xorresponding to them.
  	    for(int j=0; j<newUrls.size(); j++){
  		  HandleValue hv = (HandleValue)newUrls.elementAt(j);
		  int indx = hv.getIndex();
		  if (!curUrlIndex.containsKey(indx)){
            newUrls.removeElementAt(j);
		    j--;
		  }
	    }
	
	    log.write("Operation: Modify\n");
	    HandleValue[] modVals = new HandleValue[newUrls.size()];
	    try {
	      for (int k = 0; k < modVals.length; k++) {
	        HandleValue hv = (HandleValue)newUrls.elementAt(k);
	        modVals[k] = new HandleValue();
	        modVals[k].setIndex(hv.getIndex());
	        modVals[k].setType(Common.STD_TYPE_URL);
	        modVals[k].setData(hv.getData());
	      }
	    }
	    catch (Exception e) {
	        e.printStackTrace();
	    }
	    ModifyValueRequest mReq = new ModifyValueRequest(Util.encodeString(handle), modVals, auth);	
        records++;
        try {
          response = resolver.processRequest(mReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS) {
            successes++;
            log.write("SUCCESS:"+(lineNum-1)+":MODIFY:"+handle+"\n");
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": line "+(lineNum-1)+" "+line+"\n");

          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");
 
          //if exception CANNOT_CONNECT_TO_SERVER caught, 
          //write the line into a bacth failure file, and let try later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
        }
        try { log.flush(); } catch (Throwable t) {}
        
        //write stat info
        if (logStat != null){
          logStat.write( (System.currentTimeMillis() - eachStart)/ 1000.0f + "\n");
          try { logStat.flush(); } catch (Throwable t) {}
        }
  	  }  //if newUrls size > 0
	} //while true

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000;     //in seconds
    log.write("Batch total execution time "  + totalExec + " seconds.\n");
    
    log.write("SUMMARY:MODIFY: "+
              successes+'/'+records+" successes "+
              (records-successes)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = records>0 ? totalExec/records : Float.NaN;
    log.write("SUMMARY:MODIFY PROCESSING TIME: " + (perRequestExec) + " seconds per request.\n\n");
    
    //stat info for average processing time
    if (logStat != null){
      logStat.write( "\nTotal processing time: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
    } 
  }

  static void processBatchAlias(AuthenticationInfo auth,
                                BufferedReader in,
                                PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int lineNum = 0;

    log.write("Operation: alias\n");
    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    
    HandleValue values[] = new HandleValue[1];
    values[0] = new HandleValue();
    values[0].setIndex(0);
    values[0].setType(Common.STD_TYPE_HSALIAS);
    values[0].setData(null);

    HandleValue addValues[] = new HandleValue[1];
    addValues[0] = new HandleValue();
    addValues[0].setIndex(0);
    addValues[0].setType(Common.STD_TYPE_HSALIAS);
    addValues[0].setData(null);

    HandleValue newValues[] = new HandleValue[2];
    newValues[0] = new HandleValue();
    newValues[0].setIndex(2);
    newValues[0].setType(Common.STD_TYPE_HSALIAS);
    newValues[0].setData(null);
    newValues[1] = new HandleValue();
    newValues[1].setIndex(100);
    newValues[1].setType(Common.STD_TYPE_HSADMIN);
    newValues[1].setData(null);

    ResolutionRequest rReq = new ResolutionRequest(null, null, null, auth);
    rReq.authoritative = true;
    ModifyValueRequest mvReq = new ModifyValueRequest(null, values, auth);
    AddValueRequest avReq = new AddValueRequest(null, addValues, auth);
    RemoveValueRequest rmReq = new RemoveValueRequest(null, null, auth);
    CreateHandleRequest chReq = new CreateHandleRequest(null, newValues, auth);

    int successes = 0;
    int records = 0;
    HandleValue currentValues[];
    AbstractResponse response;

    //write proper header into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: ALIAS \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status \n\n");
    }

    long eachStart = 0;
 
    while(true) {
      try { log.flush(); } catch (Throwable t) {}

      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx<=0) {
        log.write("Invalid line ("+lineNum+"): "+line+"\n");
        continue;
      }

      //stat purpose
      if (logStat != null)
        eachStart = System.currentTimeMillis();
       
      String handleStr = line.substring(0, spaceIdx);
      byte handle[] = Util.encodeString(handleStr);
      String aliasHdlStr = line.substring(spaceIdx + 1).trim();
      byte aliasHdl[] = Util.encodeString(aliasHdlStr);
      
      records++;
      rReq.handle = handle;
      rReq.clearBuffers();
      currentValues = null;
      response = null;
      
      try {
        response = resolver.processRequest(rReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          currentValues = ((ResolutionResponse)response).getHandleValues();
        } else if(response.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
          currentValues = null;
        } else {
          log.write("ERROR: "+response.responseCode+" "+
                    AbstractMessage.getResponseCodeMessage(response.responseCode)+
                    ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
          continue;
        }
      } catch (HandleException e) {
        log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                  ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
                  
        if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
          //write to retry file if CANNOT_CONNECT_TO_SERVER caught
          writeToBatchFailure(line);
          
        continue;
      }


      // see if the current values have any aliases that we can just update
      HandleValue updateValue = null;
      Vector deleteValues = null;
      for(int i=0; currentValues!=null && i<currentValues.length; i++) {
        if(currentValues[i].hasType(Common.STD_TYPE_HSALIAS)) {
          if(updateValue==null) {
            updateValue = currentValues[i];
          } else {
            if(deleteValues==null) deleteValues = new Vector();
            deleteValues.addElement(currentValues[i]);
          }
        }
      }

      // remove extra values...
      if(deleteValues!=null) {
        rmReq.handle = handle;
        int indexesToDelete[] = new int[deleteValues.size()];
        for(int i=0; i<indexesToDelete.length; i++) {
          indexesToDelete[i] = ((HandleValue)deleteValues.elementAt(i)).getIndex();
        }
        rmReq.indexes = indexesToDelete;
        rmReq.clearBuffers();
        try {
          response = resolver.processRequest(rmReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS ||
             response.responseCode==AbstractMessage.RC_VALUES_NOT_FOUND) {
            // we're ok.
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");
            continue;
          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                    ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");
          continue;
        }
      }
      
      if(updateValue!=null) { // we will update an already existing alias...
        mvReq.handle = handle;
        mvReq.values[0].setData(aliasHdl);
        mvReq.values[0].setIndex(updateValue.getIndex());
        mvReq.values[0].setType(Common.STD_TYPE_HSALIAS);
        mvReq.clearBuffers();
        
        try {
          response = resolver.processRequest(mvReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS) {
            successes++;
            log.write("SUCCESS:"+(lineNum-1)+":ALIAS:"+handleStr+"\n");
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": line "+(lineNum-1)+" "+line+"\n");
            continue;
          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");
          
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            //write to retry file if CANNOT_CONNECT_TO_SERVER caught
            writeToBatchFailure(line);
          
          continue;
        }
      } else if(currentValues==null) { // we will create a new handle
        chReq.handle = handle;
        chReq.values[0].setData(aliasHdl);
        
        AdminRecord admin =
          new AdminRecord(Util.getZeroNAHandle(Util.getPrefixPart(chReq.handle)),
                          200, false, true, false, false, true,
                          true, true, true, true, true, true, true);
        chReq.values[1].setData(Encoder.encodeAdminRecord(admin));
        chReq.clearBuffers();
        try {
          response = resolver.processRequest(chReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS) {
            successes++;
            log.write("SUCCESS:"+(lineNum-1)+":ADD:"+handleStr+"\n");
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": trying to create handle, line "+(lineNum-1)+" "+line+"\n");
          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");

          //if CANNOT_CONNECT_TO_SERVER exception caught, write the line into a bacth failure file, and let try later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
        }
      } else { // we will create a new HS_ALIAS handle value
        avReq.handle = handle;
        avReq.values[0].setData(aliasHdl);
        avReq.values[0].setType(Common.STD_TYPE_HSALIAS);
        avReq.values[0].setIndex(getUnusedIndex(currentValues));
        avReq.clearBuffers();
        
        try {
          response = resolver.processRequest(avReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS) {
            successes++;
            log.write("SUCCESS:"+(lineNum-1)+":ALIAS:"+handleStr+"\n");
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": line "+(lineNum-1)+" "+line+"\n");
            continue;
          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");
          
          //if the exception is CANNOT_CONNECT_TO_SERVER, write to file, and retry later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
          continue;
        }
      }
      //write stat info
      if (logStat != null) {
        logStat.write( (System.currentTimeMillis() - eachStart)/ 1000.0f + "\n");
        try { logStat.flush(); } catch (Throwable t) {}
      }
    }

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000f;   //in seconds
    log.write("Batch total execution time "  + (totalExec) + " seconds.\n");
                              
    log.write("SUMMARY:ALIAS: "+
              successes+'/'+records+" successes "+
              (records-successes)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = records>0 ? totalExec/records : Float.NaN;
    log.write("SUMMARY:ALIAS PROCESSING TIME: " + (perRequestExec) + " seconds per request.\n\n");
    
    //stat info for average processing time
    if (logStat != null){
      logStat.write( "\nTotal processing time: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
    }
  }


  static void processBatchUnalias(AuthenticationInfo auth,
                                  BufferedReader in,
                                  PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int lineNum = 0;

    log.write("Operation: unalias\n");
    
    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");

    ResolutionRequest rReq = new ResolutionRequest(null, null, null, auth);
    rReq.authoritative = true;
    RemoveValueRequest rmReq = new RemoveValueRequest(null, null, auth);

    int successes = 0;
    int records = 0;
    HandleValue currentValues[];
    AbstractResponse response;

    //write proper header into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: UNALIAS \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status \n\n");
    }

    long eachStart = 0;
     
    while(true) {
      try { log.flush(); } catch (Throwable t) {}

      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;

      //stat purpose
      if (logStat != null)
        eachStart = System.currentTimeMillis();
      
      String handleStr = line.trim();
      byte handle[] = Util.encodeString(handleStr);
      
      records++;
      rReq.handle = handle;
      rReq.clearBuffers();
      currentValues = null;
      response = null;
      
      try {
        response = resolver.processRequest(rReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          currentValues = ((ResolutionResponse)response).getHandleValues();
        } else {
          log.write("ERROR: "+response.responseCode+" "+
                    AbstractMessage.getResponseCodeMessage(response.responseCode)+
                    ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
          continue;
        }
      } catch (HandleException e) {
        log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                  ": trying to retrieve handle, line "+(lineNum-1)+" "+line+"\n");
                  
                    //if the exception is CANNOT_CONNECT_TO_SERVER, write to file, and retry later
        if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
          writeToBatchFailure(line);
        continue;
      }

      // count how many aliases there are so that we can delete them.
      HandleValue updateValue = null;
      Vector deleteValues = null;
      for(int i=0; currentValues!=null && i<currentValues.length; i++) {
        if(currentValues[i].hasType(Common.STD_TYPE_HSALIAS)) {
          if(deleteValues==null) deleteValues = new Vector();
          deleteValues.addElement(currentValues[i]);
        }
      }

      // remove all existing aliases.
      if(deleteValues!=null) {
        rmReq.handle = handle;
        int indexesToDelete[] = new int[deleteValues.size()];
        for(int i=0; i<indexesToDelete.length; i++) {
          indexesToDelete[i] = ((HandleValue)deleteValues.elementAt(i)).getIndex();
        }
        rmReq.indexes = indexesToDelete;
        rmReq.clearBuffers();
        try {
          response = resolver.processRequest(rmReq);
          if(response.responseCode==AbstractMessage.RC_SUCCESS ||
             response.responseCode==AbstractMessage.RC_VALUES_NOT_FOUND) {
            // we're ok.
          } else {
            log.write("ERROR: "+response.responseCode+" "+
                      AbstractMessage.getResponseCodeMessage(response.responseCode)+
                      ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");
            continue;
          }
        } catch (HandleException e) {
          log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+
                    ": removing old aliases, line "+(lineNum-1)+" "+line+"\n");
          
          //if the exception is CANNOT_CONNECT_TO_SERVER, write to file, and retry later
          if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
            writeToBatchFailure(line);
          continue;
        }
      }

      //write stat info
      if (logStat != null) {
        logStat.write( (System.currentTimeMillis() - eachStart)/ 1000.0f + "\n");
        try { logStat.flush(); } catch (Throwable t) {}
      }

      successes++;
    }

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000f;   //in seconds
    log.write("Batch total execution time "  + (totalExec) + " seconds.\n");
                              
    log.write("SUMMARY:UNALIAS: "+
              successes+'/'+records+" successes "+
              (records-successes)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = records>0 ? totalExec/records : Float.NaN;
    log.write("SUMMARY:UNALIAS PROCESSING TIME: " + (perRequestExec) + " seconds per request.");

    //stat info for average processing time
    if (logStat != null){
      logStat.write( "\nTotal processing time: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
    }

  }

  private static final int getUnusedIndex(HandleValue values[]) {
    int nextIdx = 2;
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i]!=null && values[i].getIndex()==nextIdx) {
        nextIdx++;
        i=-1;
      }
    }
    return nextIdx;
  }
  
  static void processBatchDelete(AuthenticationInfo auth,
                                 BufferedReader in,
                                 PrintWriter out)
    throws Exception
  {
    String line;
    int spaceIdx;
    int lineNum = 0;

    log.write("Operation: delete\n");
    DeleteHandleRequest dhReq = new DeleteHandleRequest(null, auth);
  
    long timeStarted = System.currentTimeMillis();
    java.util.Calendar calStart = java.util.Calendar.getInstance();
    String currenttime = calStart.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");

    //write proper into stat file
    if (logStat != null){
      //write the header
      logStat.write("Batch action: DELETE \n");
      logStat.write("Data: processing time per request in second \n");
      logStat.write("Note: please see your log file for success status \n\n");
    }
    
    int successes = 0;
    int records = 0;
    String handle;
    
    long eachStart = 0;
    long eachEnd = 0;
    while(true) {
      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx>0) {
        handle = line.substring(0, spaceIdx).trim();
      } else {
        handle = line;
      }

      if (logStat != null) eachStart = System.currentTimeMillis();
      
      dhReq.handle = Util.encodeString(handle);
      
      records++;
      dhReq.clearBuffers();
      AbstractResponse response = null;
      try {
        response = resolver.processRequest(dhReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          successes++;
          log.write("SUCCESS:"+(lineNum-1)+":DELETE:"+handle+"\n");
        } else {
          log.write("ERROR: "+response.responseCode+" "+
                    AbstractMessage.getResponseCodeMessage(response.responseCode)+
                    ": line "+(lineNum-1)+" "+line+"\n");
        }
      } catch (HandleException e) {
        log.write("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode())+": line "+(lineNum-1)+" "+line+"\n");

        //if exception CANNOT_CONNECT_TO_SERVER caught, write the line into a bacth failure file, and let try later
        if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER)
          writeToBatchFailure(line);
      }
      try { log.flush(); } catch (Throwable t) {}
      
      if (logStat != null) {
        double fl = (System.currentTimeMillis() - eachStart)/1000.0f;
        logStat.write( (fl) + "\n");
        try { logStat.flush(); } catch (Throwable t) {}
      }
      
    }

    long timeEnded = System.currentTimeMillis();
    java.util.Calendar calEnd = java.util.Calendar.getInstance();
    String currenttime1 = calEnd.getTime().toString();
    log.write("Batch started at " + currenttime + "\n");
    log.write("Batch finished at " + currenttime1 + "\n");
    float totalExec = (timeEnded-timeStarted)/1000f;    //in seconds
    log.write("Batch total execution time "  + (totalExec) + " seconds.\n");
                
    log.write("SUMMARY:DELETE: "+
              successes+'/'+records+" successes "+
              (records-successes)+'/'+records+" errors\n");
              
    //calculate the average processing time
    float perRequestExec = (records>0 ? totalExec/records : Float.NaN);
    log.write("SUMMARY:DELETE PROCESSING TIME: " + (perRequestExec) + " seconds per request.\n\n");
    
    //stat info for average processing time
    if (logStat != null){
      logStat.write( "\nTotal processing: " + totalExec + " seconds for " + records + " records.");
      logStat.write( "\nAverage processing time: " + perRequestExec + " second per request.");
      
    }
    
  }
}
