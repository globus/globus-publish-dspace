/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.cnri.guiutil.*;
import net.cnri.util.StreamTable;
import net.handle.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.io.*;

/**
 * Window that provides an interface for a user to enter their private key
 * and identifier, usually in order to sign something.
 */
public class GetSigKeyWindow 
  extends JDialog 
  implements ActionListener
{
  private static final String SETTINGS_FILE = ".handle_siginfo";
  
  private JTextField idField;
  private JLabel privKeyLabel;
  private JButton okButton;
  private JButton cancelButton;
  private JButton loadKeyButton;
  private String authRole = "handle";
  
  private File privKeyFile = null;
  private PublicKeyAuthenticationInfo sigInfo = null;
  private boolean wasCanceled = true;
  private StreamTable storedSettings = null;
  
  public GetSigKeyWindow(Frame owner)
    throws HeadlessException
  {
    this(owner, "default");
  }
  
  /** 
   * Constructor for a window object that provides an interface for a user
   * to enter their identity and private key.  The given roleID provides
   * a key to the type of identification that is being performed, so that
   * the appropriate default ID and file are used.
   */
  public GetSigKeyWindow(Frame owner, String roleID)
    throws HeadlessException
  {
    super(owner, "Signing Key", true);
    
    if(roleID!=null)
      authRole = roleID;
    
    storedSettings = new StreamTable();
    
    try {
      storedSettings.readFromFile(System.getProperty("user.home", "")+
                                  File.separator + SETTINGS_FILE);
    } catch (Exception e) {}
    
    String privKeyFileStr = storedSettings.getStr("keyfile_"+authRole, null);
    if(privKeyFileStr!=null) 
      privKeyFile = new File(privKeyFileStr);
    
    idField = new JTextField(storedSettings.getStr("id_"+authRole, ""), 30);
    okButton = new JButton("OK");
    cancelButton = new JButton("Cancel");
    loadKeyButton = new JButton("Select Key File...");
    privKeyLabel = new JLabel("no key loaded");
    privKeyLabel.setForeground(Color.gray);
    
    JPanel p = new JPanel(new GridBagLayout());
    p.setBorder(new javax.swing.border.EmptyBorder(10,10,10,10));
    int y = 0;
    p.add(new JLabel("Your ID:"), GridC.getc(0,y).label());
    p.add(idField, GridC.getc(1,y++).field().colspan(2));
    
    p.add(new JLabel("Your Key:"), GridC.getc(0,y).label());
    p.add(privKeyLabel, GridC.getc(1,y).field());
    p.add(loadKeyButton, GridC.getc(2,y++).field().wx(0));
    
    JPanel bp = new JPanel(new GridBagLayout());
    bp.add(Box.createHorizontalStrut(100), GridC.getc(0,0).wx(1));
    bp.add(cancelButton, GridC.getc(1,0));
    bp.add(okButton, GridC.getc(2,0));
    p.add(bp, GridC.getc(0,y++).colspan(3).wx(1).fillx().insets(20,0,0,0));
    
    okButton.addActionListener(this);
    cancelButton.addActionListener(this);
    loadKeyButton.addActionListener(this);
    
    getContentPane().add(p);
    getRootPane().setDefaultButton(okButton);
    
    updateKeyLabel();
    
    pack();
    setSize(getPreferredSize());
    
    AwtUtil.setWindowPosition(this, AwtUtil.WINDOW_CENTER);
  }

  private void updateKeyLabel() {
    if(privKeyFile!=null) {
      privKeyLabel.setText(privKeyFile.getName());
    } else {
      privKeyLabel.setText("no key loaded - press the \"Load\" button");
    }
  }

  private void chooseKey() {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Select your private key file");
    int returnVal = chooser.showOpenDialog(null);
    if(returnVal != JFileChooser.APPROVE_OPTION) {
      updateKeyLabel();
      return;
    }
    
    File f = chooser.getSelectedFile();
    if(f!=null && (privKeyFile==null || !f.equals(privKeyFile))) {
      // the user selected a different file
      privKeyFile = f;
    }
    updateKeyLabel();
    return;
  }
    
  private PrivateKey loadPrivateKeyFromFile() {
    if(privKeyFile!=null) {
      try {
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        FileInputStream fin = new FileInputStream(privKeyFile);
        byte buf[] = new byte[256];
        int r = 0;
        while((r=fin.read(buf))>=0)
          bout.write(buf, 0, r);
        buf = bout.toByteArray();
        byte passphrase[] = null;
        if(Util.requiresSecretKey(buf)) {
          // ask the user for their secret key...
          PassphrasePanel pp = new PassphrasePanel();
          int result = 
            JOptionPane.showConfirmDialog(this, pp, "Enter Passphrase", 
                                          JOptionPane.OK_CANCEL_OPTION);
          if(result==JOptionPane.OK_OPTION) {
            passphrase = new String(pp.getPassphrase()).getBytes("UTF8");
          } else {
            return null;
          }
        }
        
        buf = Util.decrypt(buf, passphrase);
        
        return Util.getPrivateKeyFromBytes(buf, 0);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: "+e, 
            "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(System.err);
      }
    } else {
      JOptionPane.showMessageDialog(this, "Error: Please specify a private key file", 
          "Error", JOptionPane.ERROR);
    }
    return null;
  }
  
  private boolean checkInputs() {
    sigInfo = null;
    
    String id = idField.getText().trim();
    if(id==null || id.trim().length()<=0) {
      JOptionPane.showMessageDialog(this, 
                                    "Please enter your identifier",
                                    "No identifier specified",
                                    JOptionPane.ERROR_MESSAGE);
      return false;
    }
    
    PrivateKey privKey = loadPrivateKeyFromFile();
    if(privKey==null) return false;
    
    sigInfo = new PublicKeyAuthenticationInfo(Util.encodeString(id), 0, privKey);
    return true;
  }
  
  private void storeValues() {
    storedSettings.put("id_"+authRole, idField.getText());
    try {
      storedSettings.put("keyfile_"+authRole, privKeyFile.getCanonicalPath());
    } catch (Exception e) {}
    try {
      storedSettings.writeToFile(System.getProperty("user.home", "")+
        File.separator + SETTINGS_FILE);
    } catch (Exception e) {}
  }
  
  public boolean wasCanceled() {
    return wasCanceled;
  }
  
  public PublicKeyAuthenticationInfo getSignatureInfo() {
    if(wasCanceled) return null;
    return sigInfo;
  }
  
  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if(src==okButton) {
      if(checkInputs()) {
        wasCanceled = false;
        setVisible(false);
        storeValues();
      }
    } else if(src==cancelButton) {
      wasCanceled = true;
      setVisible(false);
    } else if(src==loadKeyButton) {
      chooseKey();
    }
  }

  
  private class PassphrasePanel
    extends JPanel
  {
    private JPasswordField passField;
    
    PassphrasePanel() {
      setLayout(new GridBagLayout());
      setBorder(new javax.swing.border.EmptyBorder(10,10,10,10));
      passField = new JPasswordField("", 30);
      
      add(new JLabel("Enter the passphrase to decrypt your private key"),
          AwtUtil.getConstraints(0,0,1,1,1,1,false,false));
      add(passField, AwtUtil.getConstraints(0,1,1,1,1,1,false,false));
      
    }
    
    char[] getPassphrase() {
      return passField.getPassword();
    }
  }
  

}
