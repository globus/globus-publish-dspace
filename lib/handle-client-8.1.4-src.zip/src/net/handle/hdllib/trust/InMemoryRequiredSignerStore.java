package net.handle.hdllib.trust;

import java.util.List;

public class InMemoryRequiredSignerStore extends AbstractRequiredSignerStore {

	public InMemoryRequiredSignerStore(List<JsonWebSignature> requiredSigners) {
		this.requiredSigners = requiredSigners;
	}
}
