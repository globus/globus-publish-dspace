package net.handle.hdllib.trust;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.cnri.util.StreamUtil;

public class FileBasedRequiredSignerStore extends AbstractRequiredSignerStore {

	protected File requiredSignersDir;
	private volatile long lastModified;
	
	public FileBasedRequiredSignerStore(File requiredSignersDir) {
		this.requiredSignersDir = requiredSignersDir;
	}
	
//	public File getDir() {
//		return certStoreDir;
//	}
	
	@Override
	public synchronized void loadSigners() {
		List<JsonWebSignature> certs = new ArrayList<JsonWebSignature>();
		long newLastModified = requiredSignersDir.lastModified();
		File[] files = requiredSignersDir.listFiles();
		if (files != null) {
			for (File f : files) {
				if (f.isDirectory()) {
					continue;
				}
				long thisFileLastModified = f.lastModified();
				if (thisFileLastModified > newLastModified) {
					newLastModified = thisFileLastModified;
				}
				try {
					String serialization = StreamUtil.readFullyAsString(f);
					JsonWebSignature cert = JsonWebSignatureFactory.getInstance().deserialize(serialization);
					if (!validateSelfSignedCert(cert)) {
						System.err.println("Required signer cert did not validate. " + f.getName());
						continue;
					}
					certs.add(cert);
				} catch (TrustException e) {
					System.err.println("Required signer cert could not be loaded. " + f.getName());
					e.printStackTrace();
				} catch (IOException e) {
					System.err.println("Required signer cert could not be loaded. " + f.getName());
					e.printStackTrace();
				}
			}
		}
		lastModified = newLastModified;
		requiredSigners = certs;
	}
	
	@Override 
	public boolean needsLoadSigners() {
		if (requiredSignersDir.lastModified() > lastModified) {
			return true;
		}
		File[] files = requiredSignersDir.listFiles();
		if (files == null) return false;
		for (File f : files) {
			if (f.isDirectory()) {
				continue;
			}
			if (f.lastModified() > lastModified) {
				return true;
			}
		}
		return false;
	}
}
