/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.BitSet;
import java.util.Vector;

public class StringUtils {
  private static final char HEX_VALUES[] = {'0','1','2','3','4','5','6','7',
                                            '8','9','A','B','C','D','E','F'};


  /***********************************************************
   * This function will return the Nth string segment in the
   * string "str" delimited by "delimiter".  If n is out of
   * the range of string segments, it will just return an
   * empty string.  The string segments start at 0.  This 
   * can probably be sped up a bit.
   * For example, fieldIndex("A:B:C:D:E",':',2) would return "C"
   ***********************************************************/
  public static final String fieldIndex(String str, char delimiter, int n) {
    int currentField=0, lastIndex=0, thisIndex;
    int strLen = str.length();
    do {
      if(currentField==n) {
        thisIndex = str.indexOf(delimiter,lastIndex);
        if(thisIndex>=0){ return str.substring(lastIndex,thisIndex);}
        else { return str.substring(lastIndex,strLen); }
      } else {
        thisIndex = str.indexOf(delimiter,lastIndex);
        if(thisIndex<0) return "";
        else {
          currentField++;
          lastIndex=thisIndex+1;
        }
      }
    } while(lastIndex<strLen);
    return "";
  }
  
  public static final int countFields(String str, char delimiter) {
      if(str==null)
          return 0;
      int count = 0;
      int idx = -1;
      do {
          count++;
          idx = str.indexOf(delimiter, idx+1);
      } while(idx>=0);
      return count;
  }
    
  public static final String[] split(String str, char ch) {
    if(str==null) return new String[0];
    int numFields = 1;
    int strLen = str.length();
    for(int i=0; i<strLen; i++) 
      if(str.charAt(i)==ch)
        numFields++;
    String result[] = new String[numFields];
    int strNum = 0;
    int idx = 0;
    for(int i=0; i<strLen; i++) {
      if(str.charAt(i)==ch) {
        result[strNum++] = str.substring(idx, i);
        idx = i+1;
      }
    }
    result[strNum] = str.substring(idx);
    return result;
  }

  /**
   * Return a copy of the given string with the characters in escChars
   * (and any backslashes) escaped with backslashes.  The unbackslash call
   * can be used to return the string to its original state.
   */
  public static final String backslash(String str, String escChars) {
    int len = str.length();
    int currPos = 0;
    StringBuilder sb = new StringBuilder(str.length());
    char ch;
    while(currPos<len) {
      ch = str.charAt(currPos);
      if(ch=='\\' || escChars.indexOf(ch)>=0) {
        sb.append('\\');
        sb.append(ch);
      } else {
        sb.append(ch);
      }
      currPos++;
    }
    return sb.toString();
  }
  
  /**
   * Return a copy of the given string with the characters in escChars
   * (and any backslashes) unescaped with backslashes.  This should perform 
   * the reverse of the backslash() call, given the same escChars 
   * parameter.
   */
  public static final String unbackslash(String str) {
    int len = str.length();
    int currPos = 0;
    char backslash = '\\';
    StringBuilder sb = new StringBuilder(str.length());
    while(currPos<len) {
      char ch = str.charAt(currPos++);
      if(ch==backslash && currPos<len) {
        sb.append(str.charAt(currPos++));  // ignore backslash, append char
      } else {
        sb.append(ch);
      }
    }
    return sb.toString();
  }
  
  public static final String decode(String str) {
    int len = str.length();
    int currPos = 0;
    StringBuilder sb = new StringBuilder(str.length());
    while(currPos<len) {
      char ch = str.charAt(currPos);
      if(ch=='\\') {
        currPos++;
        if(currPos>=len) {sb.append(ch); break;}
        ch = str.charAt(currPos);
        if(ch=='n') sb.append('\n');
        else if(ch=='t') sb.append('\t');
        else if(ch=='r') sb.append('\r');
        else sb.append(ch);
      } else {
        sb.append(ch);
      }
      currPos++;
    }
    return sb.toString();
  }


  /* Encode a string for storage... basically remove all tabs so that it
   * doesn't screw up our tab-delimited format */
  public static final String encode(String str)
  {
    StringBuilder sb = new StringBuilder("");
    for(int i=0;i<str.length();i++){
      char ch = str.charAt(i);
      switch(ch) {
        case '\t':
          sb.append("\\t");
          break;
        case '\n':
          sb.append("\\n");
          break;
        case '\r':
          sb.append("\\r");
          break;
        default:
          sb.append(ch);
      }
    }
    return sb.toString();
  }

  /** Convert the hexadecimal values into a byte array */
  public static final byte[] decodeHex(String hexString) {
    String s = hexString.toUpperCase().trim();
    byte buf[] = new byte[s.length()/2+1];
    for(int i=0; i<buf.length; i++) buf[i] = (byte)0;

    int i=0;
    boolean lowNibble = false;
    
    char ch;
    for(int c=0; c<s.length(); c++) {
      ch = s.charAt(c);
      if(ch>='0' && ch<='9') {
        if(lowNibble)
          buf[i++] |= ch-'0';
        else
          buf[i] = (byte)((ch-'0')<<4);
        lowNibble = !lowNibble;
      } else if(ch>='A' && ch<='F') {
        if(lowNibble)
          buf[i++] |= ch-'A'+10;
        else
          buf[i] = (byte)((ch-'A'+10)<<4);
        lowNibble = !lowNibble;
      }
    }
    byte realBuf[];
    if(!lowNibble) {
      realBuf = new byte[i];
    } else {
      realBuf = new byte[i+1];
    }
    System.arraycopy(buf,0,realBuf,0,realBuf.length);
    return realBuf;
    
  }
  
  /** Encode the given byte array into a string of hexadecimal characters (0-9,A-F) */
  public static final String encodeHex(byte buf[], int offset, int len, boolean formatNicely) {
    if(buf==null || buf.length<=0) return "";
    StringBuilder sb = new StringBuilder();
    for(int i=offset; i<offset+len; i++) {
      if(formatNicely && i>0 && (i%16)==0)  sb.append('\n');
      sb.append(HEX_VALUES[ ( buf[i]&0xF0 ) >>> 4 ] );
      sb.append(HEX_VALUES[ ( buf[i]&0xF ) ] );
    }
    return sb.toString();
  }
  
  /** Encode the given byte array into a string of hexadecimal characters (0-9,A-F) */
  public static final String encodeHex(byte buf[], boolean formatNicely){
    return encodeHex(buf, 0, buf.length, formatNicely); 
  }
    

  
  /** decodes the special characters in a URL encoded string *except* for
   * the + to space conversion. */
  public static String decodeURLIgnorePlus(String str) {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
  
  /** decodes the special characters in a URL encoded string *except* for
   * the + to space conversion. */
  public static String decodeURLIgnorePlus(char str[], int start, int len) {
    byte utf8Buf[] = new byte[len];
    int utf8Loc = 0;
    int strLoc = start;
    int strLen = start+len;
    while(strLoc < strLen) {
      char ch = str[strLoc++];
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str[strLoc++],
                                           str[strLoc++]);
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
  
  /** decodes the special characters in a URL encoded string. */
  public static String decodeURL(String str) {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else if(ch=='+') {
        utf8Buf[utf8Loc++] = (byte)' ';
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    } 
  }

  public static final byte decodeHexByte(char ch1, char ch2) {
    char n1 = (char) ((ch1>='0' && ch1<='9') ? ch1-'0' : ((ch1>='a' && ch1<='z') ? ch1-'a'+10 : ch1-'A'+10));
    char n2 = (char) ((ch2>='0' && ch2<='9') ? ch2-'0' : ((ch2>='a' && ch2<='z') ? ch2-'a'+10 : ch2-'A'+10));
    return (byte)(n1<<4 | n2);
  }

  private static final char hexByteMap[] = {'0','1','2','3','4','5','6','7','8',
                                            '9','A','B','C','D','E','F','G','H'};
  
  public static String encodeHexChar(byte b) {
    StringBuilder sb = new StringBuilder();
    sb.append(hexByteMap[(b&0xF0)>>4]);
    sb.append(hexByteMap[b&0x0F]);
    return sb.toString();
  }

  public static final String padr(String str, int n, char padchar) {
    StringBuilder sb = new StringBuilder(str);
    while(sb.length()<n) sb.append(padchar);
    return sb.toString();
  }

  public static final String padl(String str, int n, char padchar) {
    StringBuilder sb = new StringBuilder(str);
    while(sb.length()<n) sb.insert(0,padchar);
    return sb.toString();
  }

  public static final void sortStringArray(String array[])
  {
    quicksortAscending(array,0,array.length-1);
  }
  
  private static final void quicksortAscending(String array[], int first,
                                               int last )
  {
    int piv_index;
    if ( first < last ) { 
      piv_index = partitionAscending( array, first, last );
      quicksortAscending( array, first, piv_index - 1 );
      quicksortAscending( array, piv_index, last );
    }
  }
  
  private static final int partitionAscending( String array[], int start, 
                                               int end )
  {
    String pivot, temp;
    int first = start, last = end;
    pivot = array[ (first + last) / 2 ];
    while ( first <= last ) {
      while ( array[first].compareTo(pivot) < 0 )
        ++first;
      
      while ( array[last].compareTo(pivot) > 0 )
        --last;
      
      if ( first <= last ) {
        temp = array[first];
        array[first] = array[last];
        array[last] = temp;
        ++first;  
        --last;
      }
    }
    return (first);
  }
  
  
  public static final String[] vectorToStringArray(Vector v) {
    String a[] = new String[v.size()];
    for(int i=0; i<a.length; i++) {
      a[i] = String.valueOf(v.elementAt(i));
    }
    return a;
  }
  
  public static final String getNLengthString(int width, char fillChar) {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<width;i++)
      sb.append(fillChar);
    return sb.toString();
  }
  
  public static final String fillLeft(String str, int width, char fillChar) {
    if(str==null)
      return getNLengthString(width,fillChar);
    int strLen=str.length();
    if(strLen>=width) {
      return str.substring(0,width);
    } else /* if(strLen<width) */ {
      return getNLengthString(width-strLen,fillChar)+str;
    }
  }
  
  public static final String fillRight(String str, int width, char fillChar) {
    if(str==null)
      return getNLengthString(width,fillChar);
    int strLen=str.length();
    if(strLen>=width) {
      return str.substring(0,width);
    } else /* if(strLen<width) */ {
      return str+getNLengthString(width-strLen,fillChar);
    }
  }
  
  public static final String stripNonNumbers(String str, char decimalChar){
    StringBuffer sb = new StringBuffer("");
    int len = str.length();
    boolean gotDec=false;
    boolean firstChar=true;
    for(int i=0;i<len;i++) {
      char ch = str.charAt(i);
      if(ch>='0' && ch <='9') {
        sb.append(ch);
        firstChar=false;
      } else if(ch==decimalChar && !gotDec) {
        gotDec=true;
        sb.append(ch);
        firstChar=false;
      } else if(ch=='-' && firstChar) {
        sb.append(ch);
        firstChar=false;
      }
    }
    return sb.toString();
  }
  
  public static final boolean isInteger(String astr) {
    String str = astr.trim();
    if(str.length()<=0)
      return false;
    for(int i=str.length()-1; i>=0; i--) {
      char ch = str.charAt(i);
      if(ch<'0' || ch>'9')
        return false;
    }
    return true;
  }
  
  public static final boolean isAllNumber(String str) {
    int sz = str.length();
    for(int i=str.length()-1; i>=0; i--) {
      char ch = str.charAt(i);
      if(ch<'0' || ch>'9') return false;
    }
    return sz>0;
  }
    
  public static final String makeFileName(String str) {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if((ch >= 'A' && ch <='Z') || (ch >='a' && ch <='z') ||
          (ch >='0' && ch <= '9') || ch=='.' || ch=='_'){
        sb.append(ch);
      } else {
        sb.append('_');
      }
    }
    return sb.toString();
  }

  /**
   * Allows arbitrary text to be embedded safely in HTML or XML
   */
  public static String cgiEscape(String str) {
    if(str==null) return "null";
    StringBuilder sb = new StringBuilder("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if(ch=='<')
        sb.append("&lt;");
      else if(ch=='>')
        sb.append("&gt;");
      else if(ch=='"')
        sb.append("&quot;");
      else if(ch=='&')
        sb.append("&amp;");
      else if(ch=='\'') 
        sb.append("&#39;");
      else
        sb.append(ch);
    }
    return sb.toString();
  }

  /**
   * Allows arbitrary text to be embedded safely in HTML or XML.  Deals with whitespace normalization.  The 'quot' and 'apos' parameters determine which conversions are performed
   * (use 'quot' true for attributes in double-quotes and 'apos' true for attributes in single-quotes).
   */
  public static void xmlEscape(Appendable buf, CharSequence s, boolean quot, boolean apos) throws IOException {
      int len = s.length();
      for(int i = 0; i < len; i++) {
          char c = s.charAt(i);
          if(c=='&') buf.append("&amp;");
          else if(c=='<') buf.append("&lt;");
          else if(c=='>') buf.append("&gt;");
          else if(c=='"' && quot) buf.append("&quot;");
          else if(c=='\'' && apos) buf.append("&#39;");
          else if(c==0x9) buf.append("&#x9;");
          else if(c==0xD) buf.append("&#xD;");
          else if(c==0xA && (quot || apos)) buf.append("&#xA;"); // escape newlines in attributes
          else buf.append(c);
      }
  }

  /**
   * Allows arbitrary text to be embedded safely in HTML or XML.  Deals with whitespace normalization.  The 'attribute' parameter determines which conversions are performed.
   */
  public static String xmlEscape(CharSequence s, boolean attribute) {
      StringBuilder sb = new StringBuilder();
      try {
          xmlEscape(sb,s,attribute,attribute);
      }
      catch(IOException e) {
          throw new AssertionError(e);
      }
      return sb.toString();
  }
  
  /**
   * Allows arbitrary text to be embedded safely in HTML or XML.  Deals with whitespace normalization.  This version does all conversions (e.g. as for an attribute).
   * Note that this escapes all newlines.
   */
  public static String xmlEscape(CharSequence s) {
      return xmlEscape(s,true);
  }
  
  /**
   * {@literal Escapes <>"'&, replaces newlines with <br>, and tabs with a series of four &nbsp;.}
   */
  public static final String htmlEscapeWhitespace(String str) {
      return htmlEscapeWhitespace(str,false);
  }
  
  /**
   * {@literal Escapes <>"'&, replaces newlines with <br>, spaces with &nbsp;, and tabs with a series of four &nbsp;.}
   */
  public static final String htmlEscapeWhitespaceNonBreakingSpaces(String str) {
      return htmlEscapeWhitespace(str,true);
  }

  private static final String htmlEscapeWhitespace(String str,boolean noBreaks) {
    if(str==null) return "null";
    StringBuilder sb = new StringBuilder();
    int sz = str.length();
    for(int i=0; i<sz; i++) {
      char ch = str.charAt(i);
      if(ch=='&') sb.append("&amp;");
      else if(ch=='<') sb.append("&lt;");
      else if(ch=='>') sb.append("&gt;");
      else if(ch=='"') sb.append("&quot;");
      else if(ch=='\'') sb.append("&#39;");
      else if(ch=='\n' || ch=='\r') sb.append("<br />");
      else if(ch=='\t') sb.append("&nbsp;&nbsp;&nbsp&nbsp;");
      else if(ch==' ' && noBreaks) sb.append("&nbsp;");
      else sb.append(ch);
    }
    return sb.toString();
  }
  

  public static String sqlEscape(String str) {
    StringBuilder sb = new StringBuilder("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if(ch=='\'')
        sb.append("''");
      else if(ch=='\n')
        sb.append("\\n");
      else if(ch=='\r')
        sb.append("\\r");
      else
        sb.append(ch);
    }
    return sb.toString();
  }

  /** 
   * Encodes a URL query string component.  Spaces are replaced with %20 rather than +.
   */
  public static String encodeURLComponent(String s) {
      try {
          return URLEncoder.encode(s,"UTF-8").replace("+","%20");
      }
      catch(UnsupportedEncodingException e) {
          throw new AssertionError(e);
      }
  }
  
  private static BitSet safeURL = new BitSet(256);
  private static BitSet safeURLPath;
  private static BitSet safeURLComponentMinimal;
  static {
      for(char ch = 'a'; ch<='z'; ch++) {
          safeURL.set(ch);
      }
      for(char ch = 'A'; ch<='Z'; ch++) {
          safeURL.set(ch);
      }
      for(char ch = '0'; ch<='9'; ch++) {
          safeURL.set(ch);
      }
      String unreserved = "-._~";
      String pathGenDelims = ":@/";
      String safeSubDelims1 = "!$()*,";
      String safeSubDelims2 = ";=";
      String unsafeSubDelims = "+&'"; // generally makes life easier to encode in path
      String fullURIOnlyGenDelims = "?#[]";
      String s;
      s = unreserved + safeSubDelims1 + pathGenDelims;
      for(int i = 0; i < s.length(); i++) {
          safeURL.set(s.charAt(i));
      }
      safeURLComponentMinimal = (BitSet)safeURL.clone();
      s = safeSubDelims2;
      for(int i = 0; i < s.length(); i++) {
          safeURL.set(s.charAt(i));
      }
      safeURLPath = (BitSet)safeURL.clone();
      s = unsafeSubDelims + fullURIOnlyGenDelims;
      for(int i = 0; i < s.length(); i++) {
          safeURL.set(s.charAt(i));
      }
      safeURL.set('%',true);
  }
  
  private static String encodeURL(String s, BitSet safeChars) {
      byte[] bytes;
      try {
          bytes = s.getBytes("UTF-8");
      }
      catch(UnsupportedEncodingException e) {
          throw new AssertionError(e);
      }
      
      StringBuilder sb = new StringBuilder();
      for(byte b : bytes) {
          if(safeChars.get(b & 0xFF)) {
              sb.append((char)b);
          }
          else {
              sb.append("%");
              sb.append(encodeHexChar(b));
          }
      }
      return sb.toString();
  }
  
  /** 
   * Encodes a URL, leaving most characters alone.  It assumes all special characters present are intended to be special, including %.
   * It will only encode characters which are not legal in URLs.
   */
  public static String encodeURL(String s) {
      return encodeURL(s,safeURL);
  }

  /**
   * Encodes a URL plus replace {@literal & and ' with &amp; and &#39;}
   */
  public static String encodeURLForAttr(String s) {
      return cgiEscape(encodeURL(s));
  }
  
  /** 
   * Encodes a URL, leaving most characters alone, but encoding ? and #.
   * Also encodes +, {@literal &}, ' so that it automatically can be embedded as data anywhere in HTML.
   * Intended to use on the path component of a URI.
   */
  public static String encodeURLPath(String s) {
      return encodeURL(s,safeURLPath);
  }

  /** 
   * Encodes a URL, leaving most characters alone, but encoding ? and #, as well as ; = {@literal &}.
   * Also encodes +, {@literal &}, ' so that it automatically can be embedded as data anywhere in HTML.
   * Intended to use for component of a query string of a URI.
   */
  public static String encodeURLComponentMinimal(String s) {
      return encodeURL(s,safeURLComponentMinimal);
  }
}
