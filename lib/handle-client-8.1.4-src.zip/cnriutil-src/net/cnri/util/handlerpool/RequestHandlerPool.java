/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util.handlerpool;

/************************************************************************
 * Class that maintains a pool of available request handlers.
 * When a request handler is needed, then getHandler() method
 * should be called and a handler is selected from the pool.
 * after the request has been completed, the returnHandler
 * method should be called to put the handler back in the pool
 * at which time the resetState method will be called on the
 * handler.
 ************************************************************************/

public class RequestHandlerPool
  implements Runnable
{
  private static final int DEFAULT_POOL_SIZE = 100;
  private static final int SIZE_INCREMENT = 50;
  
  private int maxHandlerInvocations = 200;
  private RequestHandler pool[];
  private int start = 0;  // the index of the first ready handler
  private int end = 0;    // the index of the last handler (could be < start)
  private String statusID = null;
  
  /** If no handlers are available and autoSpawnHandlers is true, more handlers
    * will be constructed and added to the pool.  */
  private boolean autoSpawnHandlers = true;
  
  public RequestHandlerPool() {
    // initialize to a default size...
    pool = new RequestHandler[DEFAULT_POOL_SIZE];
    for(int i=0; i<DEFAULT_POOL_SIZE; i++) {
      pool[i] = null;
    }
  }

  public RequestHandlerPool(String statusID) {
    this();
    this.statusID = statusID;
    if(statusID!=null) {
      Thread analyzer = new Thread(this);
      analyzer.setDaemon(true);
      analyzer.start();
    }
  }

  public void setHandlerLife(int handlerLife) {
    this.maxHandlerInvocations = handlerLife;
  }

  public void run() {
    while(true) {
      try { 
        System.err.print("<"+statusID+':'+getAvailableCount()+">");
        Thread.sleep(60000);
      } catch (Exception e) {}
    }
  }

  int getAvailableCount() {
    int size = end - start;
    if(size<0)
      size = pool.length + size;
    return size;
  }
  
  public void addHandler(RequestHandler handler) {
    returnHandler(handler);
  }

  /**********************************************************************
   * Get a handler from the pool.  If none are available, wait until one
   * is available and return it.  This does not necessarily hand out
   * RequestHandlers on a first-come first-serve basis.
   **********************************************************************/
  public synchronized RequestHandler getHandler() {
    while(true) {
      // if there are handlers available, return the first one.
      if(start!=end) {
        int idx = start++;

        if(start>=pool.length) // loop around to the beginning
          start = 0;
        
        return pool[idx];
      }
      
      if(autoSpawnHandlers) {
        addHandler(pool[0].newHandler());
        continue;
      }
      
      // If no handlers are available, wait (at most a second at a time)
      // until one is available.  If one becomes available, we will wake
      // up immediately and return it
      try {
        this.wait(1000);
      } catch (Exception e) {
        System.err.println("Got exception waiting for handler: "+e);
      }    
    }
  }


  /*********************************************************************
   * Return the specified handler to the pool.  This object calls the
   * resetState() method on the object before returning it to the set
   * of available handlers.
   *********************************************************************/
  public void returnHandler(RequestHandler handler) {
    try {
      handler.resetState();
    } catch (Throwable t) {
      System.err.println("Exception resetting handler state: "+t);
    }
    
    try {
      synchronized (this) {
        // put the handler into the pool at the end of the queue
        
        if(getAvailableCount()>=(pool.length-1)) {
          System.err.println("Growing handler pool... end="+end+" pool.length="+
                             pool.length+" start="+start);
          // need to increase the pool size by SIZE_INCREMENT
          RequestHandler newPool[] = new RequestHandler[pool.length + SIZE_INCREMENT];
          int i = 0;
          
          // copy the old handlers into the new pool array...
          while(start!=end) {
            newPool[i++] = pool[start++];
            if(start>=pool.length)
              start = 0;
          }
          start = 0;
          end = i;
          pool = newPool;
        }

        int thisHandlerIdx = end++;
        if(end>=pool.length)
          end = 0;
        
        pool[thisHandlerIdx] = handler;
        if(pool[thisHandlerIdx].getInvocationCount() > maxHandlerInvocations) {
          pool[thisHandlerIdx] = handler.newHandler();
          handler.deactivate();
        }
        
        this.notify();
      }
      
    } catch(Exception e) {
      System.err.println("Error resetting handler: "+e);
    }
  }

}
