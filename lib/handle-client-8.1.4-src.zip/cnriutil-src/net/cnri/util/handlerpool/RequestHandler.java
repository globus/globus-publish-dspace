/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util.handlerpool;

/********************************************************************
 * Interface used to represent classes capable of handling
 * multiple sequential resolution requests.  The resetState()
 * method will be called between successive requests.
 ********************************************************************/

public interface RequestHandler {

  /** Resets the state of the handler and prepares it to handle
      another request. */
  public void resetState();

  /** Construct another handler that can be used to process requests.
      This should do something like clone() except this should fork a
      new thread. */
  public RequestHandler newHandler();

  /** Shut down this handler.  This should stop the handler thread and
      clean up any open resources. */
  public void deactivate();

  /** Get a count of how many times this handler has been invoked. */
  public int getInvocationCount();

}
