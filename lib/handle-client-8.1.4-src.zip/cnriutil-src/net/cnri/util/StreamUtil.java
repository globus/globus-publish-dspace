/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/** Utility functions used to ease the parsing and encoding of StreamObjects
  */
public abstract class StreamUtil {
  
  /** Read bytes from the given InputStream until an EOF is reached. */
  public static byte[] readFully(InputStream in) throws IOException {
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    byte buf[] = new byte[4096];
    int r;
    while((r=in.read(buf))>=0) {
      bout.write(buf, 0, r);
    }
    return bout.toByteArray();
  }

  /** Read bytes from the given InputStream until an EOF is reached. */
  public static int readFully(InputStream in, byte[] buf) throws IOException {
    int r;
    int off = 0;
    while((r=in.read(buf, off, buf.length - off)) > 0) {
        off += r;
    }
    return off;
  }
  
  /** Read characters from the given Reader until an EOF is reached. */
  public static String readFully(Reader in) throws IOException {
    StringBuilder sb = new StringBuilder();
    char[] buf = new char[4096];
    int r;
    while((r=in.read(buf))>=0) {
      sb.append(buf, 0, r);
    }
    return sb.toString();
  }

  /** Read bytes from the given File until an EOF is reached. */
  public static byte[] readFully(File file) throws IOException {
      InputStream in = inputStreamForFile(file);
      try {
          return readFully(in);
      } finally {
          in.close();
      }
  }
  
  /** Read bytes from the given File until an EOF is reached. */
  public static String readFullyAsString(File file) throws IOException {
      Reader in = readerForFile(file);
      try {
          return readFully(in);
      } finally {
          in.close();
      }
  }

  /** Read bytes from the given File until an EOF is reached. */
  public static byte[] readFully(String file) throws IOException {
      return readFully(new File(file));
  }
  
  /** Read bytes from the given File until an EOF is reached. */
  public static String readFullyAsString(String file) throws IOException {
      return readFullyAsString(new File(file));
  }
  
  /** Returns a list of strings, each containing one line read from the input. */
  public static List<String> readLines(BufferedReader reader) throws IOException {
      List<String> res = new ArrayList<String>();
      String line;
      while ((line = reader.readLine()) != null) {
          res.add(line);
      }
      return res;
  }

  /** Returns a list of strings, each containing one line read from the input. */
  public static List<String> readLines(Reader reader) throws IOException {
      return readLines(new BufferedReader(reader));
  }

  /** Returns a list of strings, each containing one line read from the input. */
  public static List<String> readLines(File file) throws IOException {
      return readLines(readerForFile(file));
  }

  /** Returns a list of strings, each containing one line read from the input. */
  public static List<String> readLines(String filename) throws IOException {
      return readLines(readerForFile(filename));
  }

  /** Returns a BufferedInputStream for a file's contents */
  public static BufferedInputStream inputStreamForFile(File file) throws FileNotFoundException {
      return new BufferedInputStream(new FileInputStream(file));
  }

  /** Returns a BufferedReader for a file's contents assuming UTF-8 */
  public static BufferedReader readerForFile(File file) throws FileNotFoundException {
      try {
          return new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
      } catch (UnsupportedEncodingException e) {
          throw new AssertionError(e);
      }
  }

  /** Returns a BufferedInputStream for a file's contents */
  public static BufferedInputStream inputStreamForFile(String file) throws FileNotFoundException {
      return new BufferedInputStream(new FileInputStream(new File(file)));
  }

  /** Returns a BufferedReader for a file's contents assuming UTF-8 */
  public static BufferedReader readerForFile(String file) throws FileNotFoundException {
      try {
          return new BufferedReader(new InputStreamReader(new FileInputStream(new File(file)), "UTF-8"));
      } catch (UnsupportedEncodingException e) {
          throw new AssertionError(e);
      }
  }
  
  /**************************************************************
   * Read from the specified reader until a non-whitespace
   * character is read.  When a non-whitespace character is read,
   * return it.
   **************************************************************/
  public static int getNonWhitespace(Reader in) 
    throws IOException
  {
    int ch;
    while(true) {
      ch = in.read();
      if( ch == ' ' || ch == '\n' || ch == '\r' ||
          ch == ',' || ch == ';' || ch == '\t') {
        continue;
      }
      return ch;
    }
  }
  
  /**************************************************************
   * This function reads in a string given that the string is
   * not delimited with a quote.  It will read in anything up to
   * but not including anything that might delimit a word.
   **************************************************************/
  public static String readUndelimitedString(Reader in, int firstChar)
    throws IOException
  {
    if(firstChar == -1) {
        return "";
    }      
    StringBuffer sb = new StringBuffer(""+(char)firstChar);
    int ch;
    while(true) {
      ch = in.read();
      if( ch == ' ' || ch == 10 || ch == 13 || ch == ',' || 
        ch == ';' || ch == -1 || ch == '=' || ch == '\t') {
        return sb.toString();
      } else {
        sb.append((char)ch);
      }
    }
  }
  
  /***********************************************************************
   * This function reads in a string token assuming the first qoute (")
   * has been read already.
   ***********************************************************************/
  public static String readString(Reader in) 
    throws StringEncodingException, IOException
  {
    StringBuffer results = new StringBuffer("");
    int ch;
    while(true) {
      
      ch = in.read();
      if(ch == -1) {
        throw new StringEncodingException("Unexpected End of String");
      } else if(ch == '\\') {
          ch = in.read();
          if(ch == -1) {
            throw new StringEncodingException("Unexpected End of String");
          } else if(ch == 'n') {
            results.append('\n');
          } else {
            results.append((char)ch);
          }
      } else if(ch == '"'){
        return results.toString();
      } else {
        results.append((char)ch);
      }
    }
  }


  /*****************************************************************
   * Escape all of the "special" characters in the given string and
   * return the result.
   *****************************************************************/
  public static String XencodeString(String str)
  {
    //-- This probably could use some optimization.
    StringBuffer sb = new StringBuffer("\"");
    int i,n=str.length();
    char ch;
    for( i=0; i<n; i++) {
      ch= str.charAt(i); 
      if(ch=='"' || ch == '\\')
        sb.append('\\');
      sb.append(ch);
    }
    sb.append("\"");
    return sb.toString();
  }

  public static void writeEncodedString(Writer out, String str) 
    throws IOException
  {
    int n = str.length();
    char ch;
    out.write('"');
    for ( int i=0; i<n; i++) {
      ch= str.charAt(i); 
      if(ch=='"' || ch == '\\')
        out.write('\\');
      out.write(ch);
    }
    out.write("\"");
  }
  

  public static void XwriteString(String str, Writer out) 
    throws IOException
  {
    int i,n = str.length();
    char ch;
    out.write('"');
    for(i=0;i<n;i++){
      ch = str.charAt(i);
      if(ch == '"') 
        out.write('\\');
      out.write(ch);
    }
    out.write('"');
  }
}










