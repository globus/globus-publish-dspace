/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * SimpleDateFormat is not thread-safe.  This is a drop-in replacement.
 * Using a ThreadLocal<SoftReference<DateFormat>> could be faster.
 * Prefer {@link FastDateFormat} whenever possible.
 */
public class ThreadSafeDateFormat {
    private DateFormat dateFmt;

    public ThreadSafeDateFormat(DateFormat dateFmt) {
        this.dateFmt = dateFmt;
    }
    
    public ThreadSafeDateFormat(String format) {
        this.dateFmt = new SimpleDateFormat(format);
    }

    public synchronized String format(Date date) {
        return dateFmt.format(date);
    }

    public synchronized Date parse(String string) throws ParseException {
        return dateFmt.parse(string);
    }
}
