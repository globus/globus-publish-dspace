/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.io;

import java.io.*;

/** This class provides an input stream that reads only N bytes before
    failing to read any more.  This is useful for reading 'content-length'
    bytes from http connections. */
public class LimitedInputStream
  extends InputStream
{
  private PushbackInputStream in;    // the original stream to read from
  private int bytesToRead;   // the number of bytes left to read
  
  public LimitedInputStream(InputStream in, int bytesToRead) {
    if(in instanceof PushbackInputStream) {
      this.in = (PushbackInputStream)in;
    } else {
      this.in = new PushbackInputStream(in);
    }
    this.bytesToRead = bytesToRead;
  }

  /** Reads one byte from the original stream as long as the set number of bytes
      has not already been read. */
  public int read()
    throws IOException
  {
    if(bytesToRead<=0) return -1;

    synchronized(this) {
      bytesToRead--;
      return in.read();
    }
  }

  public int read(byte buf[])
    throws IOException
  {
    return read(buf, 0, buf.length);
  }
  
  public int read(byte buf[], int start, int len)
    throws IOException
  {
    if(bytesToRead<=0) return -1;
    
    synchronized(this) {
      if(bytesToRead<=0) return -1;
      int result = in.read(buf, start, Math.min(len, bytesToRead));
      if(result>=0)
        bytesToRead -= result;
      return result;
    }
  }

  /** Pushes a single byte back onto the stream. */
  public synchronized void unread(int b)
    throws IOException
  {
    in.unread(b);
    bytesToRead++;
  }
}
