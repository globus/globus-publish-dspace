/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.io;

import java.io.*;

/** This class provides a wrapper around an input stream that prints
 out whatever is read from the given InputStream. */
public class EchoInputStream
  extends InputStream
  {
    private InputStream in;
    private OutputStream echoOut;
    private boolean closeWhenFinished;
    
    public EchoInputStream(InputStream in) {
      this(in, System.err, false);
    }
    
    public EchoInputStream(InputStream in, OutputStream echoOut) {
      this(in, echoOut, true);
    }
    
    public EchoInputStream(InputStream in, OutputStream echoOut, boolean closeWhenFinished) {
      this.in = in;
      this.echoOut = echoOut;
      this.closeWhenFinished = closeWhenFinished;
    }
    
    public int read()
    throws IOException
    {
      int b = in.read();
      if(b>=0) {
        echoOut.write(b);
      }
      return b;
    }
    
    public void close() 
    throws IOException
    {
      in.close();
      if(closeWhenFinished) echoOut.close();
    }
  }
