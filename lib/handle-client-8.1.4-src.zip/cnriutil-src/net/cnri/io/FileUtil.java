/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.io;

import java.io.*;

public abstract class FileUtil {

  private FileUtil() {}

  public static final void deleteTree(File fileOrDir)
    throws IOException
  {
    IOException e = null;

    if(fileOrDir.isDirectory()) {
      String subFiles[] = fileOrDir.list();
      for(int i=0; i<subFiles.length; i++) {
        try {
          deleteTree(new File(fileOrDir, subFiles[i]));
        } catch(IOException exc) {
          e = exc;
        }
      }
      
      if(!fileOrDir.delete()) {
        e = new IOException("Unable to remove directory: "+fileOrDir);
      }
    } else {
      fileOrDir.delete();
    }
    
    if(e!=null) throw e;
  }
}
