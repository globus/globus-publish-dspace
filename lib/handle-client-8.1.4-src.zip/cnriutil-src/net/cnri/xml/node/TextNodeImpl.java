/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.xml.node;

import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

public class TextNodeImpl implements Node {
    private final String text;
    
    public TextNodeImpl(String text) {
        this.text = text;
    }
    
    
    @Override
    public String getAttribute(String attrName) {
        return null;
    }

    @Override
    public String getAttribute(QName qname) {
        return null;
    }

    @Override
    public Map<QName,String> getAttributes() {
        return null;
    }

    @Override
    public List<Node> getChildren() {
        return null;
    }

    @Override
    public String getLocalName() {
        return null;
    }

    @Override
    public QName getName() {
        return null;
    }

    @Override
    public Map<String,String> getNamespaceContext() {
        return null;
    }

    @Override
    public Map<String,String> getNamespaceDeclarations() {
        return null;
    }

    @Override
    public String getNamespaceURI() {
        return null;
    }

    @Override
    public String getPrefix() {
        return null;
    }

    @Override
    public Node getSubElement(String elementName) {
        return null;
    }

    @Override
    public Node getSubElement(QName qname) {
        return null;
    }

    @Override
    public String getSubElementText(String elementName) {
        return null;
    }

    @Override
    public String getSubElementText(QName qname) {
        return null;
    }

    @Override
    public List<Node> getSubElements() {
        return null;
    }

    @Override
    public List<Node> getSubElements(String elementName) {
        return null;
    }

    @Override
    public List<Node> getSubElements(QName qname) {
        return null;
    }

    @Override
    public String getText() {
        return this.text;
    }

    @Override
    public boolean isText() {
        return true;
    }

}
