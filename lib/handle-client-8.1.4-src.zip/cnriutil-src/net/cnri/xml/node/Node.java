/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.xml.node;

import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

/**
 * A Node is either an element or a text node in an XML document.
 *
 * For text nodes, every method returns null except isText() and getText().
 */
public interface Node {

    /**
     * @return true if this is a text node; false if this is an element.
     */
    boolean isText();

    /**
     * @return the contents of a text node; the text contents of a text-only element; an empty String for an empty element; otherwise null.
     */
    String getText();
    
    /**
     * @return the qualified name of an element.
     */
    QName getName();

    /**
     * @return the local part of an element name.
     */
    String getLocalName();

    /**
     * @return the namespace URI of an element; an empty string for an element in no namespace.
     */
    String getNamespaceURI();

    /**
     * @return the namespace prefix of an element; an empty string for an element in its default namespace.
     */
    String getPrefix();

    /**
     * @return a map of qualified names to attribute values.
     */
    Map<QName,String> getAttributes();

    /**
     * Returns the value of an attribute with no namespace.  As opposed to the getSubElement methods, this method will not find attributes
     * with the given local name in any namespace.
     * 
     * @param attrName the name of an attribute with no namespace
     * @return the value of that attribute, or null if this element has no such attribute.
     */
    String getAttribute(String attrName);
    
    /**
     * @param qname the qualified name of an attribute
     * @return the value of that attribute, or null if this element has no such attribute.
     */
    String getAttribute(QName qname);

    /**
     * @return the namespaces declared on this element.
     */
    Map<String,String> getNamespaceDeclarations();

    /**
     * @return the namespaces currently in context on this element, including those declared on this element
     * or any ancestor without being redeclared.  Always a superset of getNamespaceDeclarations().
     */
    Map<String,String> getNamespaceContext();

    /**
     * @return a list of all children of this element, including text nodes.
     */
    List<Node> getChildren();

    /**
     * @return a list of all children of this element which are elements.
     */
    List<Node> getSubElements();

    /**
     * Returns the first subelement with the given local name, in any namespace or none.  As opposed to the getAttribute methods, this method will
     * find subelements in any namespace or none.
     * 
     * @param elementName the local name of a subelement
     * @return the first subelement with the given local name, in any namespace or none; null if no such subelement.
     */
    Node getSubElement(String elementName);

    /**
     * @param qname the qualified name of a subelement
     * @return the first subelement with the given qualified name; null if no such subelement.
     */
    Node getSubElement(QName qname);
    
    /**
     * Returns the text contents of the first subelement with the given local name, in any namespace or none.  
     * As opposed to the getAttribute methods, this method will find subelements in any namespace or none.
     * 
     * @param elementName the local name of a subelement
     * @return the text contents of the first subelement with the given local name, in any namespace or none; null if no such element, or 
     * if the first such element is not text-only.
     */
    String getSubElementText(String elementName);

    /**
     * @param qname the qualified name of a subelement
     * @return the text contents of the first subelement with the given qualified name; null if no such element, or 
     * if the first such element is not text-only.
     */
    String getSubElementText(QName qname);

    /**
     * Returns a list of all subelements with the given local name, in any namespace or none.  As opposed to the getAttribute methods, this method will
     * find subelements in any namespace or none.
     * 
     * @param elementName the local name of a subelement
     * @return a list of all subelements with the given local name, in any namespace or none.
     */
    List<Node> getSubElements(String elementName);

    /**
     * @param qname the qualified name of a subelement
     * @return a list of all subelements with the given qualified name.
     */
    List<Node> getSubElements(QName qname);

}
